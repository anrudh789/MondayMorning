
<script>
	sessionStorage.clear();
</script>
<?php echo 	redirect(base_url().'register','refresh');?>