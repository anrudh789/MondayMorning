 <?php  $base_url=base_url().'assets/';?>

                <footer id="footer">

            <div class="footer-logo">
              <img class="normal_logo" src="<?php echo $base_url?>images/monday/mm6-white.png" alt="Footer Logo" title="Footer Logo">
              <img class="retina_logo" src="<?php echo $base_url?>images/monday/mm6-white.png" alt="LMS" title="LMS" style="width:98px; height:99px;">
            </div>
            <div class="footer-widgets-wrapper">
              <div class="container">
                 <div class="column dt-sc-one-fourth first ">
                  <aside id="text-7" class="widget widget_text">
                    <h3 class="widgettitle">Navigation</h3>
                    <div class="textwidget">
                     <ul>
                        <li> <a href="#" title=""> Home </a> </li>
                        <li> <a href="#" title=""> What is MM? </a> </li>
                   
                        <li> <a href="#" title=""> How it work's  </a> </li>
                         <li> <a href="<?php echo base_url()?>faq" title=""> FAQ's</a> </li>
                        <li> <a href="#" title=""> Blog  </a> </li>
												
												  <li> <a href="#" title="">Contact </a> </li>
                      </ul>
                    </div>
                  </aside>
                </div>
                 <div class="column dt-sc-one-fourth space ">
                  <aside id="text-7" class="widget widget_text">
                    <h3 class="widgettitle">Policy</h3>
                    <div class="textwidget">
                      <ul>
                        <li> <a href="#" title=""> Terms Of Use </a> </li>
                        <li> <a href="#" title=""> Privacy Policy</a> </li>
                        
                      </ul>
                    </div>
                  </aside>
                </div>
                <div class="column dt-sc-one-fourth space ">
                  <aside id="text-7" class="widget widget_text">
                    <h3 class="widgettitle">Follow Us</h3>
                    <div class="textwidget">
                      <ul>
                        <li> <a href="#" title=""> Facebook</a> </li>
                        <li> <a href="#" title="">Twitter</a> </li>
												 <li> <a href="#" title="">LinkedIn</a> </li>
												  <li> <a href="#" title="">Medium</a> </li>
													 <li> <a href="#" title="">Google+</a> </li>
                        
                      </ul>
                    </div>
                  </aside>
                </div>
               
                <div class="column dt-sc-one-fourth ">
                  <aside id="text-8" class="widget widget_text">
                    <h3 class="widgettitle">Contact us</h3>
                    <div class="textwidget">
                      <div class="dt-sc-contact-info address">
                        <div class="icon"><i class="fa fa-location-arrow"></i>
                        </div>
                        <p>Takshashila Consulting
                          <br>The Ithum, Unit - 10, 3rd Floor,
                          <br>Tower A, Plot No. A-40,
												<br>Sector - 62, Noida - 201301, INDIA</p>
                        <p><span></span>
                        </p>
                      </div>

                      <div class="dt-sc-contact-info">
                        <div class="icon"><i class="fa fa-phone"></i>
                        </div>
                        <p> +91-120-6500778 <br>+91-120-6500708</p><span></span>
                      </div>

                      

                      <div class="dt-sc-contact-info">
                        <div class="icon"><i class="fa fa-envelope"></i>
                        </div>
                        <p><a href="info@tkc.firm.in">Info@tkc.firm.in</a>
                        </p><span></span>
                      </div>
                    </div>
                  </aside>
                </div>
              </div>
            </div>

            <div class="copyright">
              <div class="container">
                <div class="copyright-info">Copyright © <?php echo date('Y');?> Monday Morning All Rights Reserved by | <a href="<?php echo base_url()?>"
                  title="">TKC </a>
                </div>
                <ul class="social-icons">
                  <li><a href="#" target="_blank"><span class="fa fa-twitter"></span></a>
                  </li>
                  <li><a href="#" target="_blank"><span class="fa fa-youtube"></span></a>
                  </li>
                  <li><a href="#" target="_blank"><span class="fa fa-facebook"></span></a>
                  </li>
                  <li><a href="#" target="_blank"><span class="fa fa-skype"></span></a>
                  </li>
                </ul>
              </div>
            </div>
          </footer>
          <!-- **Footer - End** -->
      </div>
      <!-- **Inner Wrapper - End** -->
    </div>
    <!-- **Wrapper - End** -->