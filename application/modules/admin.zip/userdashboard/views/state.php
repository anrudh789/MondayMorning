<option value="">---Select State---</option>
<?php foreach($state as $sta){?>
<option value="<?php echo $sta['sid']?>"><?php echo $sta['name']?></option>
<?php }?>