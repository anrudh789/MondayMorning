<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web extends MX_Controller {
	
	
  function __construct()
   {
						parent::__construct();
						$this->load->model('Web_modal');
						$this->load->model('crud/Crud_modal');
						$this->load->helper('url');
						$this->load->library('session'); 
   }
	public function index()
	{
		  try
			{
				    $data['title']='Monday Morning';
						$this->load->view('templetes/head',$data);
						$this->load->view('templetes/header',$data);
						$this->load->view('index',$data);
						$this->load->view('templetes/footer');
						$this->load->view('templetes/foot');
			}
			catch (Exception $e)
			{
				echo 'Caught exception: ',  $e->getMessage(), "\n";
			}
	}
	public function aboutus()
	{
		  try
			{
				    $data['title']='Monday Morning About Us';
						$this->load->view('templetes/head',$data);
						$this->load->view('templetes/header',$data);
						$this->load->view('about',$data);
						$this->load->view('templetes/footer');
						$this->load->view('templetes/foot');
			}
			catch (Exception $e)
			{
				echo 'Caught exception: ',  $e->getMessage(), "\n";
			}
	}

	public function contactus()
	{
		  try
			{
				    $data['title']='Monday Morning Contact Us';
						$this->load->view('templetes/head',$data);
						$this->load->view('templetes/header',$data);
						$this->load->view('contact',$data);
						$this->load->view('templetes/footer');
						$this->load->view('templetes/foot');
			}
			catch (Exception $e)
			{
				echo 'Caught exception: ',  $e->getMessage(), "\n";
			}
	}
	  public function register()
	{
		  try
			{
				    $data['title']='Monday Morning Register';
						$this->load->view('templetes/head',$data);
						$this->load->view('templetes/header',$data);
						$this->load->view('register',$data);
						$this->load->view('templetes/footer');
						$this->load->view('templetes/foot');
			}
			catch (Exception $e)
			{
				echo 'Caught exception: ',  $e->getMessage(), "\n";
			}
	}
 public function howitwork()
	{
		  try
			{
				    $data['title']='Monday Morning How-it-work';
						$this->load->view('templetes/head',$data);
						$this->load->view('templetes/header',$data);
						$this->load->view('how-it-work',$data);
						$this->load->view('templetes/footer');
						$this->load->view('templetes/foot');
			}
			catch (Exception $e)
			{
				echo 'Caught exception: ',  $e->getMessage(), "\n";
			}
	}
	 public function testimonials()
	{
		  try
			{
				    $data['title']='Monday Morning Testimonials';
						$this->load->view('templetes/head',$data);
						$this->load->view('templetes/header',$data);
						$this->load->view('testimonials',$data);
						$this->load->view('templetes/footer');
						$this->load->view('templetes/foot');
			}
			catch (Exception $e)
			{
				echo 'Caught exception: ',  $e->getMessage(), "\n";
			}
	}
	public function forget()
	{
		  try
			{
				    $data['title']='Monday Morning forget';
						$this->load->view('templetes/head',$data);
						$this->load->view('templetes/header',$data);
						$this->load->view('forget',$data);
						$this->load->view('templetes/footer');
						$this->load->view('templetes/foot');
			}
			catch (Exception $e)
			{
				echo 'Caught exception: ',  $e->getMessage(), "\n";
			}
	}	
	public function blog()
	{
		  try
			{
				    $data['title']='Monday Morning blog';
						$this->load->view('templetes/head',$data);
						$this->load->view('templetes/header',$data);
						$this->load->view('blog',$data);
						$this->load->view('templetes/footer');
						$this->load->view('templetes/foot');
			}
			catch (Exception $e)
			{
				echo 'Caught exception: ',  $e->getMessage(), "\n";
			}
	}
	public function blog_detail()
	{
		  try
			{
				    $data['title']='Monday Morning blog_detail';
						$this->load->view('templetes/head',$data);
						$this->load->view('templetes/header',$data);
						$this->load->view('blog_detail',$data);
						$this->load->view('templetes/footer');
						$this->load->view('templetes/foot');
			}
			catch (Exception $e)
			{
				echo 'Caught exception: ',  $e->getMessage(), "\n";
			}
	}	
	public function faq()
	{
		  try
			{
				    $data['title']='Monday Morning FAQ';
						$this->load->view('templetes/head',$data);
						$this->load->view('templetes/header',$data);
						$this->load->view('faq',$data);
						$this->load->view('templetes/footer');
						$this->load->view('templetes/foot');
			}
			catch (Exception $e)
			{
				echo 'Caught exception: ',  $e->getMessage(), "\n";
			}
	}	
}