
<?php $base_url=base_url().'assets/'?>


<style type="text/css">
	.main-title-section-wrapper { margin:0px; }

.main-title-section-wrapper { margin:0px; }
</style>
  
         <!-- Header Wrapper -->

         <!-- **Main** -->
         <div id="main">

            <!-- Slider Section -->

            <!-- Sub Title Section -->
            <!-- ** Breadcrumb Section ** -->
            <section class="main-title-section-wrapper">
               <div class="container">
                  <div class="main-title-section">
                     <h1>Contact Us</h1>
                    
                     <!-- ** breadcrumb - End -->
                  </div>
                 </div>
				
            </section>
				<div class='content-full-width'>
					
					
				</div>
            <!-- ** Breadcrumb Section End ** -->
            <!-- Sub Title Section -->


           	<section id="primary" class="content-full-width"><!-- #post-569 -->
<div id="post-569" class="post-569 page type-page status-publish hentry">
<div class="dt-sc-clear"></div>

  <div id="responsive_map_2129679942" class="responsive-map" >
	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3502.076521958378!2d77.37018481516394!3d28.627468582419727!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cfab3a5a04edd%3A0x58f53dd0c123f384!2sTakshashila+Consulting!5e0!3m2!1sen!2sin!4v1491367208082"
					width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></div>
<div class="dt-sc-clear"></div>
<div class='dt-sc-hr-invisible  '></div>
<div class='fullwidth-section  '  style="padding-bottom:60px;">	<div class="container">
<div  class='column dt-sc-two-third  space  first'    >
<h3 class='border-title  '>Give us a message<span></span></h3>
<div role="form" class="wpcf7" id="" lang="" dir="">
<div class="screen-reader-response"></div>
<form action="" method="post" class="wpcf7-form" novalidate="novalidate">
<div style="display: none;">

</div>
<div id="contact-form">
<p>
<span class="fa fa-user"> </span>
<span class="wpcf7-form-control-wrap your-name">
	<input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Your Name" /></span>
</p>
<p>
<span class="fa fa-envelope-o"> </span>
<span class="wpcf7-form-control-wrap your-email"><input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Email" /></span>
</p>
<p>
<span class="fa fa-mobile"> </span>
<span class="wpcf7-form-control-wrap tele"><input type="tel" name="tele" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-tel" aria-invalid="false" placeholder="Phone" /></span>
</p>
<p class="textarea-field">
<span class="fa fa-file-text-o"> </span>
<span class="wpcf7-form-control-wrap your-message"><textarea name="your-message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Message"></textarea></span>
</p>
<p class="submit"> <input type="submit" value="Send Email" class="wpcf7-form-control wpcf7-submit" /> </p>
</div>
<div class="wpcf7-response-output wpcf7-display-none"></div></form></div></div>
<div  class='column dt-sc-one-third  space  '    >
	<h3 class="border-title  ">Contact Info<span></span></h3>
                           <div class="dt-sc-contact-info address">
                              <div class="icon"><i class="fa fa-location-arrow"></i>
                              </div>
                              <p>Takshashila Consulting <br>
The Ithum, Unit - 10, 3rd Floor, <br>
Tower A, Plot No. A-40, <br>
Sector - 62, Noida - 201301, INDIA
                                </p>
                              <p><span></span>
                              </p>
                           </div>
                           <div class="dt-sc-contact-info">
                              <div class="icon"><i class="fa fa-phone"></i>
                              </div>
                              <p>+91-120-3759278</p><span></span>
                           </div>
                           <div class="dt-sc-contact-info">
                              <div class="icon"><i class="fa fa-fax"></i>
                              </div>
                              <p>+91-120-3759278</p><span></span>
                           </div>
                           <div class="dt-sc-contact-info">
                              <div class="icon"><i class="fa fa-mobile-phone"></i>
                              </div>
                              <p>+91 12345 67890</p><span></span>
                           </div>
                           <div class="dt-sc-contact-info">
                              <div class="icon"><i class="fa fa-envelope"></i>
                              </div>
                              <p><a href="mailto:super@email.com">mm@tkcfirm.in</a>
                              </p><span></span>
                           </div>
                           <div class="dt-sc-contact-info">
                              <div class="icon"><i class="fa fa-globe"></i>
                              </div>
                              <p><a target="_blank" href="http://mondaymorning.co.in">http://mondaymorning.co.in</a>
                              </p><span></span>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="dt-sc-clear"></div>
                  <div class="dt-sc-hr-invisible-medium  "></div>
                  <div class="container">
                     <div class="social-bookmark"></div>
                     <div class="social-share"></div>
                  </div>
               </div>
               <!-- #post-4243 -->

            </section>
            <!-- ** Primary Section End ** -->
         </div>
         <!-- **Main - End** -->


     
      </div>
      <!-- **Inner Wrapper - End** -->
   </div>


   
