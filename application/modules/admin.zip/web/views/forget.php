<style>
.sub{
	border: medium none;
    border-radius: 3px;
    color: #ffffff;
    cursor: pointer;
    float: right;
    font-size: 14px;
    font-weight: bold;
    margin: 38px 75px !important;
    padding: 11px 20px;
    text-transform: uppercase;
	text-align: center;
}
.danger{
	background-color: #f2dede;
    border-color: #ebccd1;
    color: #a94442;
    margin-bottom: 15px;
  
    padding: 15px;
    width: 94%;
	}
.success{
	background-color: #dff0d8;
	border-color: #d6e9c6;
	color: #3c763d;
	margin-bottom: 15px;
	
	padding: 15px;
	width: 94%;
    }
</style>

<div id="main">

        <!-- Slider Section -->
        
        <!-- Sub Title Section -->
        <!-- ** Breadcrumb Section ** --> <section class="main-title-section-wrapper">
    <div class="container">
      <div class="main-title-section">
        <h1>Forgot Password </h1>      
      </div>
      
    </div>
  </section><!-- ** Breadcrumb Section End ** -->        <!-- Sub Title Section -->   

    <!-- ** Container ** -->
   	<div class="container">
   	
	<!-- ** Primary Section ** -->
	<section id="primary" class="content-full-width"><!-- #post-1063 -->
<div id="post-1063" class="post-1063 page type-page status-publish hentry">
	<div class="column dt-sc-one-third"></div>
	<div class="column dt-sc-one-third">
	
<div class="woocommerce">

<form method="post" class="login">

			<h3 style="text-align: center"><i class="fa fa-lock fa-4x"></i></h3>
			    <div class="displaynone alert danger" id="email_exsist_error" >
		      <strong> Opps! </strong> This email is not matched.
		    </div>
		   <div class="displaynone alert success" id="email_exsist_success" >
		      <strong>Congratulation! </strong> Email id is recognised with us.
		    </div>
                  <h2 style="text-align: center">Forgot Password?</h2>
                  <p style="text-align: center">You can reset your password here.</p>
			
			 <div class="form-group">
				
                        <div class="input-group">
                         
                          <input required id="user_email_pass" name="user_email" placeholder="email address" required  class="form-control"  type="email">
                        </div>
                      </div>
                      <div class="form-group">
                        <input name="recover-submit" class="sub" value="Reset Password" type="submit">
                      </div>

			
		</form>


</div>
	</div>
	<div class="column dt-sc-one-third"></div>
<div class="social-bookmark"></div><div class="social-share"></div>	
</div><!-- #post-1063 -->

	</section><!-- ** Primary Section End ** -->    
                </div><!-- **Container - End** -->
            </div>