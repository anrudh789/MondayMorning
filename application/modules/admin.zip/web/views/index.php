    <?php  $base_url=base_url().'assets/';?>
<script type="text/javascript" src="<?php echo $base_url?>js/slideramims.min.js"></script>
<script type="text/javascript" src="<?php echo $base_url?>js/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="<?php echo $base_url?>js/revolution.extension.navigation.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.dt-sc-social-link-connect {
  background-color: #0077b5;
  border: 1px solid #0077b5;
}
.dt-sc-social-link-connect {
  background-color: #0077b5;
  border: 1px solid #0077b5;
  border-radius: 3px;
  clear: both;
  color: #fff;
  display: block;
  margin: 0 auto;
  padding: 5px 0;
  position: relative;
  text-align: center;
  width: 220px;
}
.dt-sc-social-link-connect:hover {
  background-color: #0077b5;
  border: 1px solid #0077b5;
}
.rc-anchor-normal {
     height: 0px !important; 
     width: 0px !inportant; 
}
.rc-anchor-light {
     background: none !important; 
     border: none !important; 
    color: #fff !important;
}
</style>

      <div id="main">


      

         <!-- ** Primary Section ** -->
                <section id="primary" class="content-full-width">
                    <!-- #post-4757 -->
                    <div id="post-4757" class="post-4757 page type-page status-publish hentry">
                        <div class='fullwidth-section  '>
                            <div class="container">
                                <div class="column dt-sc-two-third no-space">
                                    <div class="dt-sc-subscription-frm-image">
                                        <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow:400,700'
                                        rel='stylesheet' type='text/css'>
                                        <div id="rev_slider_3_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" style="margin:0px auto;padding:0px;margin-top:0px;margin-bottom:0px;">
                                            <!-- START REVOLUTION SLIDER 5.1.4 responsitive mode -->
                                            <div id="rev_slider_3_1" class="rev_slider fullwidthabanner tp-overflow-hidden" style="display:none;" data-version="5.1.4">
                                                <ul>
                                                    <!-- SLIDE  -->
                                                    <li data-index="rs-7" data-transition="random" data-slotamount="7" data-easein="default" data-easeout="default"
                                                    data-masterspeed="300" data-thumb="<?php echo $base_url ?>/images/sub-slider2-bg-100x50.jpg"
                                                    data-rotate="0" data-saveperformance="off" data-title="Slide"
                                                    data-param1="" data-param2="" data-param3="" data-param4=""
                                                    data-param5="" data-param6="" data-param7="" data-param8=""
                                                    data-param9="" data-param10="" data-description="">
                                                        <!-- MAIN IMAGE -->
                                                        <img src="<?php  echo $base_url ?>images/sub-slider2-bg.jpg" alt="" width="780" height="500" data-bgposition="center top"
                                                        data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg"
                                                        data-no-retina>
                                                        <!-- LAYERS -->

                                                     
                                                    </li>
                                                    <!-- SLIDE  -->
                                                    <li data-index="rs-8" data-transition="random" data-slotamount="7" data-easein="default" data-easeout="default"
                                                    data-masterspeed="300" data-thumb="<?php echo $base_url ?>/images/sub-slider3-bg-100x50.jpg"
                                                    data-rotate="0" data-saveperformance="off" data-title="Slide"
                                                    data-param1="" data-param2="" data-param3="" data-param4=""
                                                    data-param5="" data-param6="" data-param7="" data-param8=""
                                                    data-param9="" data-param10="" data-description="">
                                                        <!-- MAIN IMAGE -->
                                                        <img src="<?php  echo $base_url ?>images/sub-slider3-bg.jpg" alt="" width="780" height="500" data-bgposition="center top"
                                                        data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg"
                                                        data-no-retina>
                                                        <!-- LAYERS -->

                                                   
                                                    </li>
                                                    <!-- SLIDE  -->
                                                    <li data-index="rs-9" data-transition="random" data-slotamount="7" data-easein="default" data-easeout="default"
                                                    data-masterspeed="300" data-thumb="<?php echo $base_url ?>/images/sub-slider1-bg-100x50.jpg"
                                                    data-rotate="0" data-saveperformance="off" data-title="Slide"
                                                    data-param1="" data-param2="" data-param3="" data-param4=""
                                                    data-param5="" data-param6="" data-param7="" data-param8=""
                                                    data-param9="" data-param10="" data-description="">
                                                        <!-- MAIN IMAGE -->
                                                        <img src="<?php  echo $base_url ?>images/sub-slider1-bg.jpg" alt="" width="780" height="500" data-bgposition="center top"
                                                        data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg"
                                                        data-no-retina>
                                                        <!-- LAYERS -->

                                                        <!-- LAYER NR. 1 -->
                                                        <div class="tp-caption   tp-resizeme" id="slide-9-layer-1" data-x="76" data-y="98" data-width="auto" data-height="auto"
                                                        data-transform_idle="" data-transform_in="x:-200px;skX:85px;opacity:0;s:1000;e:Power3.easeInOut;"
                                                        data-transform_out="auto:auto;s:300;" data-start="1000"
                                                        data-responsive_offset="on" style="z-index: 5;">
                                                          <img src="<?php  echo $base_url ?>images/Home-Page-slider-3.png"
                                                            alt="" width="378" height="214" data-no-retina>
                                                        </div>

                                                        
                                                     
                                                    </li>
                                                </ul>
                                                <div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>
                                            </div>
                                            <script>
                                                var htmlDiv = document.getElementById(
                                                    "rs-plugin-settings-inline-css");
                                                var htmlDivCss =
                                                    ".tp-caption.cus_sub_title1,.cus_sub_title1{font-family:\"Raleway\",sans-serif;color:#303030;font-size:26px;line-height:30px;font-weight:600;border-width:0px;border-color:rgb(48,48,48);border-style:none}.tp-caption.cus_sub_title2,.cus_sub_title2{font-family:\"Raleway\",sans-serif;color:#6b6b6b;font-size:16px;line-height:26px;font-weight:500;border-width:0px;border-color:rgb(107,107,107);border-style:none}.tp-caption.cus_sub_title3,.cus_sub_title3{text-decoration:none;font-family:\"Raleway\",sans-serif;font-size:26px;line-height:normalpx;font-weight:500;padding:15px 20px 5px 20px;border-width:0px;border-color:rgb(34,34,34);border-style:none;background:rgba(255,255,255,0.9)}.tp-caption.cus_sub_title4,.cus_sub_title4{font-family:\"Raleway\",sans-serif;font-size:16px;line-height:26px;color:#303030;font-weight:600;padding:15px 20px;border-width:0px;border-color:rgb(48,48,48);border-style:none;background:rgba(255,255,255,0.9)}.tp-caption.cus_sub_title5,.cus_sub_title5{font-family:\"Raleway\",sans-serif;font-size:40px;font-weight:600;border-width:0px;border-color:rgb(34,34,34);border-style:none;margin:0px}.tp-caption.cus_sub_title6,.cus_sub_title6{font-family:\"Raleway\",sans-serif;font-size:28px;font-weight:400;border-width:0px;border-color:rgb(34,34,34);border-style:none;margin:0px}";
                                                if (htmlDiv)
                                                {
                                                    htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
                                                }
                                                else
                                                {
                                                    var htmlDiv = document.createElement("div");
                                                    htmlDiv.innerHTML = "<style>" + htmlDivCss + "</style>";
                                                    document.getElementsByTagName("head")[0].appendChild(
                                                        htmlDiv.childNodes[0]);
                                                }
                                            </script>
                                            <script type="text/javascript">
                                                /******************************************
                                                				-	PREPARE PLACEHOLDER FOR SLIDER	-
                                                			******************************************/

                                                var setREVStartSize = function()
                                                {
                                                    try
                                                    {
                                                        var e = new Object,
                                                            i = jQuery(window).width(),
                                                            t = 9999,
                                                            r = 0,
                                                            n = 0,
                                                            l = 0,
                                                            f = 0,
                                                            s = 0,
                                                            h = 0;
                                                        e.c = jQuery('#rev_slider_3_1');
                                                        e.gridwidth = [780];
                                                        e.gridheight = [500];

                                                        e.sliderLayout = "auto";
                                                        if (e.responsiveLevels && (jQuery.each(e.responsiveLevels,
                                                                function(e, f)
                                                                {
                                                                    f > i && (t = r = f, l = e), i >
                                                                        f && f > r && (r = f, n = e)
                                                                }), t > r && (l = n)), f = e.gridheight[l] ||
                                                            e.gridheight[0] || e.gridheight, s = e.gridwidth[
                                                                l] || e.gridwidth[0] || e.gridwidth, h =
                                                            i / s, h = h > 1 ? 1 : h, f = Math.round(h *
                                                                f), "fullscreen" == e.sliderLayout)
                                                        {
                                                            var u = (e.c.width(), jQuery(window).height());
                                                            if (void 0 != e.fullScreenOffsetContainer)
                                                            {
                                                                var c = e.fullScreenOffsetContainer.split(
                                                                    ",");
                                                                if (c) jQuery.each(c, function(e, i)
                                                                    {
                                                                        u = jQuery(i).length > 0 ? u -
                                                                            jQuery(i).outerHeight(!0) :
                                                                            u
                                                                    }), e.fullScreenOffset.split("%").length >
                                                                    1 && void 0 != e.fullScreenOffset &&
                                                                    e.fullScreenOffset.length > 0 ? u -=
                                                                    jQuery(window).height() * parseInt(e.fullScreenOffset,
                                                                        0) / 100 : void 0 != e.fullScreenOffset &&
                                                                    e.fullScreenOffset.length > 0 && (u -=
                                                                        parseInt(e.fullScreenOffset, 0))
                                                            }
                                                            f = u
                                                        }
                                                        else void 0 != e.minHeight && f < e.minHeight &&
                                                            (f = e.minHeight);
                                                        e.c.closest(".rev_slider_wrapper").css(
                                                        {
                                                            height: f
                                                        })

                                                    }
                                                    catch (d)
                                                    {
                                                        console.log("Failure at Presize of Slider:" + d)
                                                    }
                                                };


                                                setREVStartSize();

                                                function revslider_showDoubleJqueryError(sliderID)
                                                {
                                                    var errorMessage =
                                                        "Revolution Slider Error: You have some jquery.js library include that comes after the revolution files js include.";
                                                    errorMessage +=
                                                        "<br> This includes make eliminates the revolution slider libraries, and make it not work.";
                                                    errorMessage +=
                                                        "<br><br> To fix it you can:<br>&nbsp;&nbsp;&nbsp; 1. In the Slider Settings -> Troubleshooting set option:  <strong><b>Put JS Includes To Body</b></strong> option to true.";
                                                    errorMessage +=
                                                        "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jquery.js include and remove it.";
                                                    errorMessage =
                                                        "<span style='font-size:16px;color:#BC0C06;'>" +
                                                        errorMessage + "</span>";
                                                    jQuery(sliderID).show().html(errorMessage);
                                                }
                                                var tpj = jQuery;
                                                tpj.noConflict();
                                                var revapi3;
                                                tpj(document).ready(function()
                                                {
                                                    if (tpj("#rev_slider_3_1").revolution ==
                                                        undefined)
                                                    {
                                                        revslider_showDoubleJqueryError(
                                                            "#rev_slider_3_1");
                                                    }
                                                    else
                                                    {
                                                        revapi3 = tpj("#rev_slider_3_1").show().revolution(
                                                        {
                                                            sliderType: "standard",
                                                            jsFileLocation: "js",
                                                            sliderLayout: "auto",
                                                            dottedOverlay: "none",
                                                            delay: 9000,
                                                            navigation:
                                                            {
                                                                keyboardNavigation: "off",
                                                                keyboard_direction: "horizontal",
                                                                mouseScrollNavigation: "off",
                                                                onHoverStop: "on",
                                                                touch:
                                                                {
                                                                    touchenabled: "on",
                                                                    swipe_threshold: 0.7,
                                                                    swipe_min_touches: 1,
                                                                    swipe_direction: "horizontal",
                                                                    drag_block_vertical: false
                                                                },
                                                                bullets:
                                                                {
                                                                    enable: true,
                                                                    hide_onmobile: false,
                                                                    style: "persephone",
                                                                    hide_onleave: false,
                                                                    direction: "horizontal",
                                                                    h_align: "center",
                                                                    v_align: "bottom",
                                                                    h_offset: 0,
                                                                    v_offset: 20,
                                                                    space: 5,
                                                                    tmp: ''
                                                                }
                                                            },
                                                            visibilityLevels: [1240, 1024,
                                                                778, 480
                                                            ],
                                                            gridwidth: 780,
                                                            gridheight: 500,
                                                            lazyType: "none",
                                                            shadow: 0,
                                                            spinner: "spinner0",
                                                            stopLoop: "off",
                                                            stopAfterLoops: -1,
                                                            stopAtSlide: -1,
                                                            shuffle: "off",
                                                            autoHeight: "off",
                                                            disableProgressBar: "on",
                                                            hideThumbsOnMobile: "off",
                                                            hideSliderAtLimit: 0,
                                                            hideCaptionAtLimit: 0,
                                                            hideAllCaptionAtLilmit: 0,
                                                            debugMode: false,
                                                            fallbacks:
                                                            {
                                                                simplifyAll: "off",
                                                                nextSlideOnWindowFocus: "off",
                                                                disableFocusListener: false,
                                                            }
                                                        });
                                                    }
                                                }); /*ready*/
                                            </script>
                                            <script>
                                                var htmlDivCss = unescape(
                                                    ".persephone.tp-bullets%20%7B%0A%7D%0A.persephone.tp-bullets%3Abefore%20%7B%0A%09content%3A%22%20%22%3B%0A%09position%3Aabsolute%3B%0A%09width%3A100%25%3B%0A%09height%3A100%25%3B%0A%09background%3A%23transparent%3B%0A%09padding%3A10px%3B%0A%09margin-left%3A-10px%3Bmargin-top%3A-10px%3B%0A%09box-sizing%3Acontent-box%3B%0A%7D%0A.persephone%20.tp-bullet%20%7B%0A%09width%3A12px%3B%0A%09height%3A12px%3B%0A%09position%3Aabsolute%3B%0A%09background%3A%23aaa%3B%0A%09border%3A1px%20solid%20%23e5e5e5%3B%09%0A%09cursor%3A%20pointer%3B%0A%09box-sizing%3Acontent-box%3B%0A%7D%0A.persephone%20.tp-bullet%3Ahover%2C%0A.persephone%20.tp-bullet.selected%20%7B%0A%09background%3A%23222%3B%0A%7D%0A.persephone%20.tp-bullet-image%20%7B%0A%7D%0A.persephone%20.tp-bullet-title%20%7B%0A%7D%0A%0A"
                                                );
                                                var htmlDiv = document.getElementById(
                                                    'rs-plugin-settings-inline-css');
                                                if (htmlDiv)
                                                {
                                                    htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
                                                }
                                                else
                                                {
                                                    var htmlDiv = document.createElement('div');
                                                    htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
                                                    document.getElementsByTagName('head')[0].appendChild(
                                                        htmlDiv.childNodes[0]);
                                                }
                                            </script>
                                        </div>
                                        <!-- END REVOLUTION SLIDER -->
                                    </div>
                                </div>
                <div class="column dt-sc-one-third no-space">

                  <div class="dt-sc-subscription-frm-container">
                  <h2> <i class="fa fa-clock-o"> </i> Sign Up </h2>
									<?php if($this->session->flashdata('email_exsist')!="" || $this->session->flashdata('email_exsist')!=null){?>
                <div class="alert alert-danger"> <strong>Opps!</strong>     
            <?php echo $this->session->flashdata('email_exsist');?>
						</div>
                <?php }?>
                  
                       <?php if($this->session->flashdata('captcha_error')!="" || $this->session->flashdata('captcha_error')!=null){?>
                <div class="alert alert-danger">      
            <?php echo $this->session->flashdata('captcha_error');
           ?>
            </div>
                <?php }?>
		    <div id="reg-success" class="displaynone alert alert-success"  >
			
		      <strong>Congratulation!</strong>  You have succesfully register in the Monday Morning For further details check your Email inbox or Spam Folder.
		    </div>
                 <div class="displaynone alert alert-danger" id="email_exsist_error" >
		      <strong>Opps!</strong>  This email is already Registered.
		    </div>
		   <div class="displaynone alert alert-success" id="email_exsist_success" >
		      <strong>Congratulation!</strong>  You Can use this email id.
		    </div>
		   
                    <div class="dt-sc-clear"></div>
                  
                  
           <form  action="<?php echo base_url()?>sign-up" class="dt-sc-subscription-frm" method="post" autocomplete="off">
			<input maxlength="30" placeholder="Full Name (required)" name="fullname" required type="text" autocomplete="off">
			<input maxlength="50" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"  placeholder="Email (required)" name="user_email" required type="email" id="user_email" autocomplete="off">
	<!--		<div class="selection-box">
			<select name="age" required>
				<option value="" >--Selec Age--</option>
				<?php for($ag=20;$ag<=35;$ag++){?>
				
				<option value="<?php echo $ag?>"><?php echo $ag?></option>
				<?php }?>
				
				
			</select>
			</div>
			<br><br><br>
			<div class="selection-box">
			<select name="hsq" required >
				<option value="">--Select Highest Qualification--</option>
				<option value="1">Graduate</option>
				<option value="2" >Post Graduate</option>
			</select>
			</div>-->
		    
			<input maxlength="20" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" placeholder="Password (required)" name="user_password" required type="password" id="pswd" autocomplete="off">
			
			
			<div>
			<div class="g-recaptcha" data-sitekey="6LdBJx0UAAAAAPz3p4F753mLbIjeb3-I4amP36rJ"></div>
			</div>
                         <div class="container-full-width">
			<div class="column dt-sc-one-two no-space">		
                        <button type="submit" class="dt-sc-button" value="Submit" name="user_sign_up" id="usersignup">Submit</button></div>
		 
			 <div class="dt-sc-social-logins-container">
				
				<div class="dt-sc-social-logins-divider">Or</div>
		
			<!--	<a onclick="javascript:login();" href="#" class="dt-sc-social-facebook-connect">
					<i class="fa fa-facebook"></i> Connect With Facebook </a>-->
				<div class="dt-sc-hr-invisible"></div>
				<a onclick="javascript:liAuth()" href="#" class="dt-sc-social-link-connect">
					<i class="fa fa-linkedin"></i> Connect with linkedin </a>
				<div class="dt-sc-hr-invisible">
						
					</div>
			</div>
			</div>
                     
                    </form>
                    
                  </div>

                </div>
              </div>
            </div>
            <div class="dt-sc-hr-invisible  "></div>


            <section id="primary" class="content-full-width">
              <!-- #post-5009 -->
              <div id="post-5009" class="post-5009 page type-page status-publish hentry">
                <div class="fullwidth-section  ">
                  <div class="container">
                    <div class="dt-sc-hr-invisible-medium  "></div>
                     <div class="column dt-sc-one-fifth  space  first">
                      <div class="dt-sc-ico-content type14">
                        <div class="custom-icon"><a href="#" target="_blank">
		    <img src='<?php echo $base_url ?>images/Do-it-Yourself.png' width='100' height='100' ></a>
                        </div>
                        <h4><a href="#" target="_blank"> Do It Yourself </a></h4>
                      </div>
                    </div>
                    <div class="column dt-sc-one-fifth  space ">
                      <div class="dt-sc-ico-content type14">
                        <div class="custom-icon"><a href="#" target="_blank">
		    <img src='<?php echo $base_url ?>images/MM Dashboard.png' width='100' height='100' ></a>
                        </div>
                        <h4><a href="#" target="_blank"> MM Dashboard </a></h4>
                      </div>
                    </div>
                  
                    <div class="column dt-sc-one-fifth  space  ">
                      <div class="dt-sc-ico-content type14">
                        <div class="custom-icon"><a href="#" target="_blank">
		    <img src='<?php echo $base_url ?>images/Grade-Your-Skills.png' width='100' height='100' ></a>
                        </div>
                        <h4><a href="#" target="_blank"> Grade Your Skill </a></h4>
                      </div>
                    </div>
                    <div class="column dt-sc-one-fifth  space  ">
                      <div class="dt-sc-ico-content type14">
                        <div class="custom-icon"><a href="#" target="_blank">
		    <img src='<?php echo $base_url ?>images/job.png' width='100' height='100'></a>
                        </div>
                        <h4><a href="#" target="_blank"> Jobs </a></h4>
                      </div>
                    </div>
                      <div class="column dt-sc-one-fifth  space  ">
                      <div class="dt-sc-ico-content type14">
                        <div class="custom-icon"><a href="#" target="_blank">
		     <img src='<?php echo $base_url ?>images/int.png' width='100' height='100'></a>
                        </div>
                        <h4><a href="#" target="_blank">Intellectual Property </a></h4>
                      </div>
                    </div>
                    <div class="dt-sc-hr-invisible-medium " id="menu-item-4749"></div>
                    <h2 class="border-title  ">What is Monday Morning?<span></span></h2>
                    <div class="column dt-sc-one-third  space  first">
                      <h3> Monday Morning</h3>
          <p style='text-align: justify'>Mondaymorning.co.in  is an initiative for the elite intellectuals to help them transform their journey of life. We believe we will
          be the first internet company to be able to drive the intellectual capacity of the young future leaders.</p>
                      <div class="dt-sc-hr-invisible-small  "></div>
                      <p style='text-align: justify'>The premise of the platform is based on the philosophy of Do It Yourself, everyday, every week. We believe youngsters
                      need to look at life in a 1000 Monday framework and should be able to create learning agenda for every Monday while exploring new
                      avenues of life.</p>
                      <div class="dt-sc-hr-invisible-small  "></div>
                      <a href="#" target="_blank" class="dt-sc-button   small  ">READ MORE</a>
                    </div>
                    <div class="column dt-sc-two-third  space  ">
                       <img src='<?php  echo $base_url ?>images/about.jpg' width='100%' height='300' style='height: auto'>
                    </div>
                 
                    <!--<div class="column dt-sc-one-fourth first backg">
                      <p><img class="size-full wp-image-4763" src="<?php  echo $base_url ?>images/lms-banner1.jpg"
                        alt="monday morning" height="210" width="420">
                      </p>
		  
                     
                    </div>
                    <div class="column dt-sc-one-fourth   ">
                      <p><img class="size-full wp-image-4763" src="<?php  echo $base_url ?>images/Do-you-have-a-plan-for-next.png"
                        alt="monday morning" height="210" width="420">
                      </p>
                    </div>
                    <div class="column dt-sc-one-fourth">
                      <p><img class="size-full wp-image-4764" src="<?php  echo $base_url ?>images/Useful-life-comprises-of.png"
                        alt="monday morning" height="210" width="100%">
                      </p>
                    </div>
                    <div class="column dt-sc-one-fourth">
                      <p><img class="size-full wp-image-4764" src="<?php  echo $base_url ?>images/What-is-your-intellectual.png"
                        alt="monday morning" height="210" width="100%">
                      </p>
                    </div>-->
                    <div class="dt-sc-hr-invisible-medium  "></div>
                    <h2 class="border-title aligncenter ">Blog<span></span></h2>
                    <div class="column dt-sc-one-third first">
                      <article class="blog-entry no-border post-486 post type-post status-publish format-image has-post-thumbnail hentry category-post-format-audio category-photoshop tag-creative tag-design tag-news-2 post_format-post-format-image">
                        <div class="blog-entry-inner">
                          <div class="entry-thumb">
                            <a href="http://wedesignthemes.com/themes/lms/blog/image-minus-id-quod/"><img src="<?php  echo $base_url ?>images/blog15-420x295.jpg"
                              class="attachment-blogcourse-three-column-single-sidebar size-blogcourse-three-column-single-sidebar wp-post-image"
                              alt="blog15" srcset="http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-420x295.jpg 420w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-300x211.jpg 300w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-1024x719.jpg 1024w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-100x70.jpg 100w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15.jpg 1170w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-880x618.jpg 880w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-590x415.jpg 590w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-573x403.jpg 573w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-429x302.jpg 429w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-431x303.jpg 431w"
                              sizes="(max-width: 420px) 100vw, 420px" height="295" width="420">
                            </a>
                            <div class="entry-thumb-desc">
                              <p>Monday Morning.................</p>
                            </div>
                          </div>
                          <!-- .entry-thumb -->
                          <div class="entry-details">
                            <div class="featured-post"> <span class="fa fa-trophy"> </span> <span class="text">Featured</span>
                            </div>
                            <div class="entry-meta">
                              <div class="date">28 Jan </div>
                              <a href="http://wedesignthemes.com/themes/lms/blog/image-minus-id-quod/" class="entry_format"></a>
                            </div>
                            <div class="entry-title">
                              <h4><a href="http://wedesignthemes.com/themes/lms/blog/image-minus-id-quod/">Image - Minus id quod</a></h4>
                            </div>
                            <div class="entry-metadata">
                              <p class="author"><i class="fa fa-user"> </i> <a href="http://wedesignthemes.com/themes/lms/blog/author/ram/">ram</a>
                              </p><span> | </span>
                              <p class="tags"><i class="fa fa-tags"> </i><a href="http://wedesignthemes.com/themes/lms/blog/tag/creative/"> creative</a>,
                                <a href="http://wedesignthemes.com/themes/lms/blog/tag/design/"> design</a>,
                                <a href="http://wedesignthemes.com/themes/lms/blog/tag/news-2/"> news</a>
                              </p>
                              <span> | </span>
                              <p class="comments"><a href="http://wedesignthemes.com/themes/lms/blog/image-minus-id-quod//#respond"
                                class="comments"><span class="fa fa-comments"> </span> 0</a>
                              </p>
                            </div>
                          </div>
                        </div>
                      </article>
                    </div>
                    <div class="column dt-sc-one-third">
                      <article class="blog-entry no-border post-484 post type-post status-publish format-gallery has-post-thumbnail hentry category-post-format-audio category-news category-photoshop tag-blog-2 tag-chat post_format-post-format-gallery">
                        <div class="blog-entry-inner">
                          <div class="entry-thumb">
                            <div class="bx-wrapper" style="max-width: 100%; margin: 0px auto;">
                              <div class="bx-viewport" style="width: 100%; overflow: hidden; position: relative; height: 277px;">
                                <ul class="entry-gallery-post-slider" style="width: 615%; position: relative; left: -394px;">
                                  <li style="float: left; list-style: outside none none; position: relative; width: 394px;" class="bx-clone">
                                    <img src="<?php  echo $base_url ?>images/blog6-420x295.jpg"
                                    height="295" width="420">
                                  </li>
                                  <li style="float: left; list-style: outside none none; position: relative; width: 394px;"><img src="<?php  echo $base_url ?>images/blog16-420x295.jpg"
                                    height="295" width="420">
                                  </li>
                                  <li style="float: left; list-style: outside none none; position: relative; width: 394px;"><img src="<?php  echo $base_url ?>images/blog14-420x295.jpg"
                                    height="295" width="420">
                                  </li>
                                  <li style="float: left; list-style: outside none none; position: relative; width: 394px;"><img src="<?php  echo $base_url ?>images/blog4-420x295.jpg"
                                    height="295" width="420">
                                  </li>
                                  <li style="float: left; list-style: outside none none; position: relative; width: 394px;"><img src="<?php  echo $base_url ?>images/blog6-420x295.jpg"
                                    height="295" width="420">
                                  </li>
                                  <li style="float: left; list-style: outside none none; position: relative; width: 394px;" class="bx-clone"><img src="<?php  echo $base_url ?>images/blog16-420x295.jpg"
                                    height="295" width="420">
                                  </li>
                                </ul>
                              </div>
                              <div class="bx-controls bx-has-controls-direction">
                                <div class="bx-controls-direction"><a class="bx-prev" href="">Prev</a><a class="bx-next" href="">Next</a>
                                </div>
                              </div>
                            </div>
                            <div class="entry-thumb-desc">
                              <p>There are many variations of passages of Lorem Ipsum...</p>
                            </div>
                          </div>
                          <!-- .entry-thumb -->
                          <div class="entry-details">
                            <div class="entry-meta">
                              <div class="date">28 Jan </div>
                              <a href="#" class="entry_format"></a>
                            </div>
                            <div class="entry-title">
                              <h4><a href="#">Gallery - Cumque nihil impedit</a></h4>
                            </div>
                            <div class="entry-metadata">
                              <p class="author"><i class="fa fa-user"> </i> <a href="#">ram</a>
                              </p><span> | </span>
                              <p class="tags"><i class="fa fa-tags"> </i><a href="#"> blog</a>,
                                <a href="#"> chat</a>
                              </p> <span> | </span>
                              <p class="comments"><a href="#"
                                class="comments"><span class="fa fa-comments"> </span> 0</a>
                              </p>
                            </div>
                          </div>
                        </div>
                      </article>
                    </div>
                    <div class="column dt-sc-one-third">
                      <article class="blog-entry no-border post-482 post type-post status-publish format-status has-post-thumbnail hentry category-magazine category-photography category-photoshop tag-blog-2 tag-chat post_format-post-format-status">
                        <div class="blog-entry-inner">
                          <div class="entry-thumb">
                            <a href="#"><img src="<?php  echo $base_url ?>images/blog17-420x295.jpg"
                              class="attachment-blogcourse-three-column-single-sidebar size-blogcourse-three-column-single-sidebar wp-post-image"
                              alt="blog17" srcset="http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-420x295.jpg 420w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-300x211.jpg 300w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-1024x719.jpg 1024w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-100x70.jpg 100w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17.jpg 1170w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-880x618.jpg 880w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-590x415.jpg 590w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-573x403.jpg 573w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-429x302.jpg 429w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-431x303.jpg 431w"
                              sizes="(max-width: 420px) 100vw, 420px" height="295" width="420">
                            </a>
                            <div class="entry-thumb-desc">
                              <p>There are many variations of passages of Lorem Ipsum...</p>
                            </div>
                          </div>
                          <!-- .entry-thumb -->
                          <div class="entry-details">
                            <div class="entry-meta">
                              <div class="date">28 Jan </div>
                              <a href="#" class="entry_format"></a>
                            </div>
                            <div class="entry-title">
                              <h4><a href="#">Latin words Ipsum</a></h4>
                            </div>
                            <div class="entry-metadata">
                              <p class="author"><i class="fa fa-user"> </i> <a href="#">ram</a>
                              </p><span> | </span>
                              <p class="tags"><i class="fa fa-tags"> </i><a href="#"> blog</a>,
                                <a href="#"> chat</a>
                              </p> <span> | </span>
                              <p class="comments">
                                <a href="#" class="comments"><span class="fa fa-comments"> </span> 2</a>
                              </p>
                            </div>
                          </div>
                        </div>
                      </article>
                    </div>
                  </div>
                </div>
                <div class="dt-sc-hr-invisible-medium  "></div>
                <div class="fullwidth-section custom-parallax dt-sc-parallax-section" style="background-image: url(&quot;http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/09/parallax-light-white.jpg&quot;); background-repeat: no-repeat; background-attachment: fixed;">
                  <div class="container">
                    <div class="dt-sc-hr-invisible-medium  "></div>
                    <div class="dt-sc-hr-invisible-medium  "></div>
                    <div class="column dt-sc-one-fourth  space  first">
                      <div class="dt-sc-ico-content type13">
                        <div class="" ><a href="#" target="_blank">
		    <img src='<?php  echo $base_url ?>images/planet.png' width='120' height='120'>
                        </a>
                        </div>
                        <h4><a href="#" target="_blank">Know Your Business Planet</a></h4>
                      </div>
                    </div>
                    <div class="column dt-sc-one-fourth  space  ">
                      <div class="dt-sc-ico-content type13">
                        <div class="" ><a href="#" target="_blank">
		    <img src='<?php  echo $base_url ?>images/Play-Numbers.png' width='120' height='120'></a>
                        </div>
                        <h4><a href="#" target="_blank"> Play With Numbers </a></h4>
                      </div>
                    </div>
                    <div class="column dt-sc-one-fourth  space  ">
                      <div class="dt-sc-ico-content type13">
                        <div class="" ><a href="#" target="_blank">
                          <img src='<?php  echo $base_url ?>images/Elevtor-Page.png' width='120' height='120'></a>
                        </div>
                        <h4><a href="#" target="_blank"> Elevator Page </a></h4>
                      </div>
                    </div>
                    <div class="column dt-sc-one-fourth  space  ">
                      <div class="dt-sc-ico-content type13">
                         <div class="" ><a href="#" target="_blank">
                      <img src='<?php  echo $base_url ?>images/insight.png' width='120' height='120'></a>
                        </div>
                        <h4><a href="#" target="_blank"> Insight </a></h4>
                      </div>
                    </div>
                   
                   
                    <div class="dt-sc-hr-invisible-medium  "></div>
                    <div class="dt-sc-hr-invisible  "></div>
                  </div>
                </div>
                <div class="dt-sc-hr-invisible-medium  "></div>
                <div class="fullwidth-section  ">
                  <div class="container">
                    <h2 class="border-title  ">Testimonials<span></span></h2>
                    <div class="dt-sc-events-carousel-wrapper">
                      <div class="caroufredsel_wrapper" style="display: block; text-align: start; float: none; position: relative; top: auto; right: auto; bottom: auto; left: auto; z-index: auto; width: 1180px; height: 141px; margin: 0px 0px 20px; overflow: hidden;">
                        <ul class="dt-sc-events-carousel" style="text-align: left; float: none; position: absolute; top: 0px; right: auto; bottom: auto; left: 0px; margin: 0px; width: 4720px; height: 141px;">
                          <li class="dt-sc-one-half column " id="post-3636" style="width: 572px;">
                            <div class="dt-sc-event-container">
                              <div class="dt-sc-event-thumb">
                                <a href="#" title="Welcoming 25th Batch"><img src="<?php  echo $base_url ?>images/course11-420x295.jpg"
                                  class="attachment-blogcourse-three-column size-blogcourse-three-column wp-post-image"
                                  alt="course11" title="Welcoming 25th Batch"
                                  height="295" width="420">
                                </a><span class="event-price">$60</span>
                              </div>
                              <div class="dt-sc-event-content">
                                <h2><a href=#">Welcoming 25th Batch</a></h2>
                                <div class="dt-sc-event-meta">
                                  <p> <i class="fa fa-calendar-o"> </i>Jul 2017 @ 08 am - Mar 2025 @ 10 pm </p>
                                  <p>
                                    <i class="fa fa-map-marker"> </i><a href="http://wedesignthemes.com/themes/lms/venue/peppard-hill/">Peppard Hill</a>,
                                    United States<a href="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=AL+United+States"
                                    title="Peppard Hill" target="_blank"> + Google Map </a>
                                  </p>
                                </div>
                              </div>
                            </div>
                          </li>
                          <li class="dt-sc-one-half column " id="post-3639" style="width: 572px;">
                            <div class="dt-sc-event-container">
                              <div class="dt-sc-event-thumb">
                                <a href="http://wedesignthemes.com/themes/lms/event/fast-track-course-opening/" title="Fast Track Course Opening"><img src="<?php  echo $base_url ?>images/course9-420x295.jpg"
                                  class="attachment-blogcourse-three-column size-blogcourse-three-column wp-post-image"
                                  alt="course9" title="Fast Track Course Opening"
                                  height="295" width="420">
                                </a><span class="event-price">$20</span>
                              </div>
                              <div class="dt-sc-event-content">
                                <h2><a href="http://wedesignthemes.com/themes/lms/event/fast-track-course-opening/">Fast Track Course Opening</a></h2>
                                <div class="dt-sc-event-meta">
                                  <p> <i class="fa fa-calendar-o"> </i>Aug 2017 @ 09 am - Aug 2024 @ 06 pm </p>
                                  <p>
                                    <i class="fa fa-map-marker"> </i>
                                    <a href="#">Rippon Building</a>,
                United Kingdom<a href="#"
                                    title="Rippon Building" target="_blank"> + Google Map </a>
                                  </p>
                                </div>
                              </div>
                            </div>
                          </li>
                          <li class="dt-sc-one-half column " id="post-3633" style="width: 572px;">
                            <div class="dt-sc-event-container">
                              <div class="dt-sc-event-thumb">
                                <a href="#" title="Free Yoga Class at London"><img src="<?php  echo $base_url ?>images/course5-420x295.jpg"
                                  class="attachment-blogcourse-three-column size-blogcourse-three-column wp-post-image"
                                  alt="course5" title="Free Yoga Class at London"
                                  srcset="http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/05/course5-420x295.jpg 420w,
                                 
                                  sizes="(max-width: 420px) 100vw, 420px" height="295" width="420">
                                </a>
                              </div>
                              <div class="dt-sc-event-content">
                                <h2><a href="http://wedesignthemes.com/themes/lms/event/free-seminar-at-london/">Free Yoga Class at London</a></h2>
                                <div class="dt-sc-event-meta">
                                  <p> <i class="fa fa-calendar-o"> </i>Sep 2015 @ 10 am - Oct 2020 @ 06 pm </p>
                                  <p>
                                    <i class="fa fa-map-marker"> </i><a href="#">Pound Lane</a>,
                                    United States<a href="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Thov+Bridge+Las+Angels+United+States"
                                    title="Pound Lane" target="_blank"> + Google Map </a>
                                  </p>
                                </div>
                              </div>
                            </div>
                          </li>
                        </ul>
                      </div>
                      <div class="carousel-arrows">
                        <a class="events-prev" href="" style="display: block;"></a>
                        <a class="events-next" href="" style="display: block;"></a>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="dt-sc-hr-invisible-medium  "></div>
                <div class="fullwidth-section skin-color dt-sc-parallax-section" style="background-image:url(http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/newsletter-parallax.png);background-repeat:no-repeat;background-position:left top;background-attachment:fixed; ">
                  <div class="container">
                    <div class="dt-sc-hr-invisible-medium  "></div>
                    <section id="newsletter">
                      <h2 class="border-title aligncenter">Get in touch with us</h2>
                      <h6> There are many variations of passages of Lorem Ipsum 
available, but the majority have suffered alteration in some form, by 
injected humour, or randomised words which Ipsum slightly believable </h6>
                      <form name="frmNewsletter" method="post" class="dt-sc-subscribe-frm">
                        <input name="dt_mc_emailid" id="dt_mc_emailid" required="" placeholder="Your Email Address" type="email">
                        <input name="dt_mc_apikey" id="dt_mc_apikey" value="c94a1d38b6683d601a324aeeb4d4ffe3-us1" type="hidden">
                        <input name="dt_mc_listid" id="dt_mc_listid" value="314bbca712" type="hidden">
                        <input name="submit" class="dt-sc-button small" value="Subscribe" type="submit">
                      </form>
                      <div id="ajax_newsletter_msg"></div>
                    </section>
                    <div class="dt-sc-hr-invisible-medium  "></div>
                  </div>
                </div>
                <div class="dt-sc-hr-invisible-medium  "></div>
               <div class="fullwidth-section  ">
                  <div class="container">
                    <h2 class="border-title aligncenter ">Our Process<span></span></h2>
                    <div class="dt-sc-hr-invisible  "></div>
                      <img src='<?php  echo $base_url ?>images/process-2.png' >
                  </div>
                </div>
							 <div class="dt-sc-hr-invisible-medium  "></div>
                <div class="container">
                  <div class="social-bookmark"></div>
                  <div class="social-share"></div>
                </div>
              </div>
              <!-- #post-3633 -->

            </section>
            <!-- ** Primary Section End ** -->
          </div>
    

