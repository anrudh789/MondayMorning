<?php $base_url=base_url().'assets/';?>
<style>
.border-title {
    position: relative;
    text-transform: uppercase;
    float: left;
    clear: both;
    width: 100%;
    margin-bottom: 35px;}
		.trgl {
    border-radius: 3px 3px 0px 0px;
    font-size: 16px;
    font-weight: 600;
    text-transform: uppercase;
    padding: 12px 15px;
    text-shadow: none;
    margin: 0px;
}
		</style>

<div id="main">

    <!-- Slider Section -->

    <!-- Sub Title Section -->
    <!-- ** Breadcrumb Section ** -->
    <section class="main-title-section-wrapper">
        <div class="container">
            <div class="main-title-section">
                <h1>How It Works</h1>
                <div class="breadcrumb">
                   
                </div>
                <!-- ** breadcrumb - End -->
            </div>
           
        </div>
    </section>
    <!-- ** Breadcrumb Section End ** -->
    <!-- Sub Title Section -->


    <!-- ** Primary Section ** -->
    <section id="primary" class="content-full-width">
        <!-- #post-4238 -->
        <div id="post-4238" class="post-4238 page type-page status-publish hentry">
            <div class='fullwidth-section  '>
                <div class="container">
                    <h2 class='border-title aligncenter '>Our Process<span></span></h2>
                     <img src="<?php echo $base_url?>images/silder-process-chart-21.gif" style="margin-left: 200px;">
                    
                    <div class='dt-sc-hr-invisible  '></div>
                   <div class='column dt-sc-one-fifth  space first '>
   <div class='dt-sc-titled-box green darkred'  >
      <h6 class='dt-sc-titled-box-title dt-sc-toggle'><a href="#" style="color: #fff;"> Step 00<span style="float: right"><i class="fa fa-angle-down"></i></span></a></h6>
      <div class='dt-sc-titled-box-content dt-sc-toggle-content'>Do you want to upgrade Skill</div>
   </div>
</div>
<div class='column dt-sc-one-fifth  space '>
   <div class='dt-sc-titled-box darkorang'>
      <h6 class='dt-sc-titled-box-title dt-sc-toggle'><a href="#" style="color: #fff;"> Step 01<span style="float: right"><i class="fa fa-angle-down"></i></span></a></h6>
      <div class='dt-sc-titled-box-content dt-sc-toggle-content'>Register(Plegde x-Hours Per week)</div>
   </div>
</div>
<div class='column dt-sc-one-fifth  '>
   <div class='dt-sc-titled-box darkyellow '>
      <h6 class='dt-sc-titled-box-title dt-sc-toggle'><a href="#" style="color: #fff;"> Step 02<span style="float: right"><i class="fa fa-angle-down"></i></span></a></h6>
      <div class='dt-sc-titled-box-content dt-sc-toggle-content'>Follow Your Plegde</div>
   </div>
</div>
<div class='column dt-sc-one-fifth '>
   <div class='dt-sc-titled-box  darkblue'>
      <h6 class='dt-sc-titled-box-title dt-sc-toggle'><a href="#" style="color: #fff;"> Step 03<span style="float: right"><i class="fa fa-angle-down"></i></span></a></h6>
      <div class='dt-sc-titled-box-content dt-sc-toggle-content'>Compare yourself with Other</div>
   </div>
</div>
<div class='column dt-sc-one-fifth  space  '>
   <div class='dt-sc-titled-box  darkgreen'>
      <h6 class='dt-sc-titled-box-title dt-sc-toggle'><a href="#" style="color: #fff;"> Step 04<span style="float: right"><i class="fa fa-angle-down"></i></span></a></h6>
      <div class='dt-sc-titled-box-content dt-sc-toggle-content'>Create your work (jobs)</div>
   </div>
</div>

                   
                </div>
            </div>
            <div class='dt-sc-hr-invisible-medium  '></div>
            <div class='fullwidth-section  dt-sc-parallax-section'
								 style="background-image:url(http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/parallax-light2.jpg);background-repeat:no-repeat;background-position:left top;background-attachment:fixed; ">
                <div class="container">
                    <div class='dt-sc-hr-invisible-medium  '></div>
                    <div class='column dt-sc-one-full  space  first'>
                        <h3 class='border-title  '>Process of Monday Morning<span></span></h3>
                        <p style="text-align: justify;">
You are a young professional aspiring to reach higher altitudes in your career. The ecosystem that you are part of does give you an opportunity to learn and be aware of some of the business aspects of the world. However, your horizons are farther and you will realize the length and breath of skilling your own potential once you take a quick peek into the diverse and well designed assignments that we have here for you.

Our planet is in number of ways very connected and often applying what is true in some situations will work well in others too. Our effort is to make you cognizant with the today's realities of the business world and how these are impacting the planet and in turn lives of individual who form its part. 

                        </p>
                       
                    </div>
                    
                    <div class='dt-sc-hr-invisible-medium  '></div>
                </div>
            </div>
         
             <div class='dt-sc-hr-invisible-medium  '></div>
                    
           

    </section>
		
</div>
<!-- **Main - End** -->
