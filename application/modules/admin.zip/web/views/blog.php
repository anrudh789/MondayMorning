<?php $base_url=base_url().'assets/';?>
        <div id="main">
<section class="main-title-section-wrapper">
	<div class="container">
		<div class="main-title-section">
	<h1>Blog </h1>
	
	</div>
	<div class="header-search"> 
	</div>	</div>
</section> 
		
   	<div class="container">
   	
	<!-- ** Primary Section ** -->
	<section id="primary" class="content-full-width">
<div id="post-525" class="post-525 page type-page status-publish hentry">
<div class="social-bookmark"></div>
<div class="social-share"></div>	
</div>


		<div class="dt-sc-clear"></div>

		
		<div class='tpl-blog-holder  '>
				<div class=" column blog-thumb first">
					
					<article id="post-486" class="blog-entry post-486 post type-post status-publish format-image has-post-thumbnail sticky hentry
					category-post-format-audio category-photoshop tag-creative tag-design tag-news-2 post_format-post-format-image">
						<div class="blog-entry-inner">

							<div class="entry-thumb">
								
					   <a href="" title="A Day in the Life of a Class 10 Student">
            <img src='<?php echo $base_url?>images/blog15-420x295.jpg' width='420' height='295' />
						 </a>
  	<div class="entry-thumb-desc">
			<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form,
	by injected humour, or randomised words which don't look even slightly believable. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil
	impedit quo...</p></div>
								 							</div>

							<div class="entry-details">

																	
								                                
                                <div class="entry-meta">
                                    <div class="date  ">
                                        09 Apr                                    </div>
               <a href="" title="Monday Morning Blog-1" class="entry_format"> </a>
                                </div>

								<div class="entry-title">
									<h4>
							<a href="<?php echo base_url()?>blog-detail" title="Monday Morning Blog-1">Monday Morning Blog-1</a>
									</h4>
								</div>

								<div class="entry-metadata">

									<p class="author ">
										<i class="fa fa-user"> </i>
										<a href="" title="View all posts by">John</a>
									</p>
									<span class=""> | </span>

									<p class='tags tags'>
										<i class='fa fa-tags'> </i>
		<a href="" rel="tag">Assignment</a>, <a href="" rel="tag">Blog</a>,
		<a href="" rel="tag">news</a></p> <span class='tags'> | </span>
									<p class=" hidden  category">
										<i class="fa fa-sitemap"> </i>
										<a href="">Audio</a>,
										<a href="">Photoshop</a></p>
									<span class=" hidden "> | </span>

									<p class=" comments  comments">
										<a href=""><span class="fa fa-comments-o"> </span> 0</a>									</p>	
								</div><!--  .entry-metadata -->
                                
				<div class="entry-details-desc"><p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration
				in some form, by injected humour, or randomised words which don't look even slightly believable. Nam libero tempore, cum soluta nobis est eligendi
				optio cumque nihil impedit quo...</p></div>
								 
							</div>

						</div>
					</article>
				</div>

		

			
				<div class=" column blog-thumb first">
					<!-- #post-482 starts -->
					<article id="post-482" class="blog-entry post-482 post type-post status-publish format-status has-post-thumbnail hentry category-magazine category-photography category-photoshop tag-blog-2 tag-chat post_format-post-format-status">
						<div class="blog-entry-inner">

							<div class="entry-thumb">
							 <a href="<?php echo base_url()?>blog-detail" title="Latin words Ipsum">
								<img src='<?php echo $base_url?>images/blog17-420x295.jpg' width='420' height='295' /></a>
          <div class="entry-thumb-desc">
						<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or
						randomised words which don't look even slightly believable. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo...</p>
					</div>
								 							</div>

							<div class="entry-details">

								                                
                                <div class="entry-meta">
                                    <div class="date  ">
                                        10 Apr                                    </div>
                                    <a href="" title="Monday Morning Blog-2" class="entry_format"> </a>
                                </div>

								<div class="entry-title">
									<h4>
										<a href="<?php echo base_url()?>blog-detail" title="Latin words Ipsum">Monday Morning-Blog 2</a>
									</h4>
								</div>

								<div class="entry-metadata">

									<p class="author ">
										<i class="fa fa-user"> </i>
										<a href="" title="View all posts by ">ram</a>
									</p>
									<span class=""> | </span>

									<p class='tags tags'><i class='fa fa-tags'> </i><a href="" rel="tag">Blog</a>, <a href="" rel="tag">Assignment</a></p>
									<span class='tags'> | </span>
									<p class=" hidden  category"><i class="fa fa-sitemap"> </i> <a href="">News</a>,
									<a href="">Assignment</a>, <a href="">Blog</a></p>
									<span class=" hidden "> | </span>

									<p class=" comments  comments">
										<a href=""><span class="fa fa-comments-o"> </span> 2</a></p>	
								</div>
                                
						<div class="entry-details-desc">
							<p>There are many variations of passages of Lorem Ipsum available, but the majority
						have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.
						Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo...</p></div>
								 
							</div>

						</div>
					</article><!-- #post-482 Ends -->
				</div>

        </div><!-- .tpl-blog-holder  -->

		<!-- **Pagination** -->
		<div class="pagination">
			<div class="prev-post"></div>
			<ul class=''><li class='active-page'>1</li><li>
			<a href='' class='inactive'>2</a></li>
			<li><a href='' class='inactive'>3</a></li></ul>
			<div class="next-post"><a href="" >Next <span class="fa fa-angle-double-right"></span></a>
			</div>
		</div>
	</section>
		</div>
            </div>

