<div id="main">

    <!-- Slider Section -->

    <!-- Sub Title Section -->
    <!-- ** Breadcrumb Section ** -->
    <section class="main-title-section-wrapper">
        <div class="container">
            <div class="main-title-section">
                <h1>FAQ's</h1>
                <div class="breadcrumb">
                   
                </div>
                <!-- ** breadcrumb - End -->
            </div>
           
        </div>
    </section>
	
	
	 <!-- ** Primary Section ** -->
    <section id="primary" class="content-full-width">
        <!-- #post-4238 -->
        <div id="post-4238" class="post-4238 page type-page status-publish hentry">
            <div class='fullwidth-section  '>
                <div class="container">
                    
					<div class="column dt-sc-one-full ">
<div class="dt-sc-toggle-frame-set "><h5 class="dt-sc-toggle-accordion active"><a href="#">What is Monday Morning? </a></h5>
<div class="dt-sc-toggle-content" style="display: block;">
	<div class="block">Monday Morning is a platform conceptualized with the thought of building the skills and intellectual capacity of future leaders of the country to the next level. This is conceived from the thought that India needs talent which is passionately aspired, multi-skilled across various disciplines, industries and functions and can hold a big picture view while evaluating and addressing situations. We aspire to prepare young individuals bridge the skill gap and be corporate ready with all the requisite skill to be successful in the business world. The thought is to keep it simple, specific and quick in the way we perceive, assimilate and structure our knowledge and thoughts.</div>
</div>
<h5 class="dt-sc-toggle-accordion"><a href="#">Why should I solve challenges?</a></h5>
<div class="dt-sc-toggle-content" style="display: none;">
<div class="block">For Fun. What's more exciting than solving challenging problems? We're constantly adding helpful features to make our platform the
best possible experience, such as boilerplate code and animations that display when you're running code. </div>
</div>
<h5 class="dt-sc-toggle-accordion"><a href="#">How do I create challenges on Monday Morning?</a></h5>
<div class="dt-sc-toggle-content" style="display: none;">
<div class="block">Check out our challenge creation guidelines to make your own private challenges. Once you're familiar with our platform,
we're always looking for talented problem setters and testers. </div>
</div>
<h5 class="dt-sc-toggle-accordion"><a href="#">Can I create my own Assignment?</a></h5>
<div class="dt-sc-toggle-content" style="display: none;">
<div class="block">Yes! Create custom contests using Monday Morning Assignment, or write your own original content.
Check out our challenge creation guidelines and start competing with your friends!</div>
</div>
<h5 class="dt-sc-toggle-accordion"><a href="#">How do I test and submit my Assignment?</a></h5>
<div class="dt-sc-toggle-content" style="display: none;">
<div class="block">When you finish the first Assignment, click Run Code button to run your solution against one or more small sample test cases.
Once you're confident your solution covers the entire problem, click Submit to run it against the entire set of test cases (or bots) and get a
score for the challenge. Don't worry if you don't pass all the test cases, you can always rework your code and submit it again for an updated score.
The score that shows up on the leaderboard will be the one for your top-scoring submission.</div>
</div>
<h5 class="dt-sc-toggle-accordion"><a href="#">Can I share my Assignment or solution?</a></h5>
<div class="dt-sc-toggle-content" style="display: none;">
<div class="block">Don't share hints/Assignment/strategy during a live contest — it violates the contest rules. It's always nice to help a fellow programmer learn,
but posting spoilers during a competition makes it unfair. Once the contest ends, feel free to compare solutions with other coders and help others
learn how it's done!</div>
</div></div></div>
				</div></div></div></section>
</div>