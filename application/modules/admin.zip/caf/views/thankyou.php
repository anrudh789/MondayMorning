
<div id="main">

    <!-- Slider Section -->

    <!-- Sub Title Section -->
    <!-- ** Breadcrumb Section ** -->
    <section class="main-title-section-wrapper">
        <div class="container">
            <div class="main-title-section">
                <h1>Thank You</h1>
                
                <!-- ** breadcrumb - End -->
            </div>
           
        </div>
    </section>
    <!-- ** Breadcrumb Section End ** -->
    <!-- Sub Title Section -->


    <!-- ** Primary Section ** -->
    <section id="primary" class="content-full-width">
        <!-- #post-4238 -->
        <div id="post-4238" class="post-4238 page type-page status-publish hentry">
            <div class='fullwidth-section  '>
              <h2 class='border-title aligncenter '>Thank you for giving your information.<span></span></h2>
            </div>
        </div>
        <!-- #post-4389 -->

    </section>
    <!-- ** Primary Section End ** -->
</div>
<!-- **Main - End** -->


