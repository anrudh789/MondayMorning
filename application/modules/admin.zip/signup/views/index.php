    <?php  $base_url=base_url().'assets/';?>

<div id="main">
        <section id="primary" class="content-full-width">
          <!-- #post-4757 -->
          <div id="post-4757" class="post-4757 page type-page status-publish hentry">
            <div class="fullwidth-section  ">
              <div class="container">
                <div class="column dt-sc-two-third no-space">
                  <div class="dt-sc-subscription-frm-image">
                    <link href="<?php echo $base_url?>css/css.css" rel="stylesheet" type="text/css">
                    <div id="rev_slider_3_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container tp-mouseover"
                         style="margin: 0px auto; padding: 0px; height: 499px; overflow: visible;">
                      <!-- START REVOLUTION SLIDER 5.1.4 responsitive mode -->
                      <div id="rev_slider_3_1" class="rev_slider fullwidthabanner tp-overflow-hidden revslider-initialised tp-simpleresponsive"
                      style="margin-top: 0px; margin-bottom: 0px; height: 499px;" data-version="5.1.4">
                        <ul class="tp-revslider-mainul" style="visibility: visible; display: block; overflow: hidden; width: 779px; height: 100%; max-height: none; left: 0px;">
                          <!-- SLIDE  -->
                          <li data-index="rs-7" data-transition="random" data-slotamount="7" data-easein="default" data-easeout="default"
                          data-masterspeed="300" data-thumb="http://wedesignthemes.com/themes/lms/wp-content/uploads/revslider/subscription/sub-slider2-bg-100x50.jpg"
                          data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2=""
                          data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8=""
                          data-param9="" data-param10="" data-description="" class="tp-revslider-slidesli" style="width: 100%; height: 100%; overflow: hidden; z-index: 18; visibility: hidden; opacity: 0; background-color: rgba(255, 255, 255, 0);">
                            <!-- MAIN IMAGE -->
                            <div class="slotholder" style="width: 100%; height: 100%; visibility: inherit; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
                              <!--Runtime Modification - Img tag is Still Available for SEO Goals in Source - <img src="http://wedesignthemes.com/themes/lms/wp-content/uploads/revslider/subscription/sub-slider2-bg.jpg" alt="" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg defaultimg" data-no-retina="" height="500" width="780">-->
                              <div class="tp-bgimg defaultimg" style="background-color: transparent; background-repeat: no-repeat; background-image: url(&quot;http://wedesignthemes.com/themes/lms/wp-content/uploads/revslider/subscription/sub-slider2-bg.jpg&quot;); background-size: cover; background-position: center top; width: 100%; height: 100%; opacity: 1; visibility: inherit; z-index: 20;"
                              src="http://wedesignthemes.com/themes/lms/wp-content/uploads/revslider/subscription/sub-slider2-bg.jpg"></div>
                            </div>
                            <!-- LAYERS -->

                            <!-- LAYER NR. 1 -->
                            <div class="tp-parallax-wrap" style="position: absolute; visibility: hidden; left: 419px; top: 86px; z-index: 5;">
                              <div class="tp-loop-wrap" style="position:absolute;">
                                <div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;">
                                  <div class="tp-caption cus_sub_title1   tp-resizeme" id="slide-7-layer-1" data-x="420" data-y="86" data-width="auto"
                                  data-height="auto" data-transform_idle="" data-transform_in="x:-200px;skX:85px;opacity:0;s:1000;e:Power3.easeInOut;"
                                  data-transform_out="auto:auto;s:300;" data-start="1000" data-splitin="none" data-splitout="none"
                                  data-responsive_offset="on" style="z-index: 5; white-space: nowrap; border-color: rgb(48, 48, 48); visibility: hidden;
                                  transition: none 0s ease 0s ; line-height: 30px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px;
                                  font-weight: 600; font-size: 26px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0;
                                  transform: matrix3d(1, 0, 0, 0, 0.996195, 0.0871557, 0, 0, 0, 0, 1, 0, -199.6, 0, 0, 1); transform-origin: 50% 50% 0px;">
                                    Looking for Quality
                                    <br style="transition: none 0s ease 0s ; line-height: 30px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 600; font-size: 26px;"> Courses?
                                  </div>
                                </div>
                              </div>
                            </div>

                            <!-- LAYER NR. 2 -->
                            <div class="tp-parallax-wrap" style="position: absolute; visibility: hidden; left: 419px; top: 168px; z-index: 6;">
                              <div class="tp-loop-wrap" style="position:absolute;">
                                <div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;">
                                  <div class="tp-caption cus_sub_title2   tp-resizeme" id="slide-7-layer-2" data-x="420" data-y="168" data-width="auto"
                                  data-height="auto" data-transform_idle="" data-transform_in="x:200px;skX:-85px;opacity:0;s:1000;e:Quart.easeIn;"
                                  data-transform_out="auto:auto;s:300;" data-start="1000" data-splitin="none" data-splitout="none"
                                  data-responsive_offset="on" style="z-index: 6; white-space: nowrap; border-color: rgb(107, 107, 107); visibility: hidden; transition: none 0s ease 0s ; line-height: 26px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 500; font-size: 16px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: matrix3d(1, 0, 0, 0, -0.996195, 0.0871557, 0, 0, 0, 0, 1, 0, 199.6, 0, 0, 1); transform-origin: 50% 50% 0px;">You have made the right choice. LMS
                                    <br style="transition: none 0s ease 0s ; line-height: 26px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 500; font-size: 16px;"> with courses created by professions.
                                    <br style="transition: none 0s ease 0s ; line-height: 26px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 500; font-size: 16px;"> Be a Professional.
                                  </div>
                                </div>
                              </div>
                            </div>

                            <!-- LAYER NR. 3 -->
                            <div class="tp-parallax-wrap" style="position: absolute; visibility: hidden; left: 419px; top: 263px; z-index: 7;">
                              <div class="tp-loop-wrap" style="position:absolute;">
                                <div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;">
                                  <div class="tp-caption   tp-resizeme" id="slide-7-layer-3" data-x="420" data-y="264" data-width="auto" data-height="auto"
                                  data-transform_idle="" data-transform_in="y:50px;opacity:0;s:1000;e:Power3.easeInOut;"
                                  data-transform_out="auto:auto;s:300;" data-start="2000" data-splitin="none" data-splitout="none"
                                  data-responsive_offset="on" style="z-index: 7; white-space: nowrap; visibility: hidden; transition: none 0s ease 0s ; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 14px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 49.9px, 0px); transform-origin: 50% 50% 0px;"><a href='javascript:alert("click");' class="dt-sc-button small filled" style="transition: none 0s ease 0s ;
                                  line-height: 22px; border-width: 2px; margin: 10px 0px 0px; padding: 13px 20px 11px; letter-spacing: 0px;
                                  font-weight: 400; font-size: 14px;">Subscribe To <br> Monday Morning</a>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </li>
                          <!-- SLIDE  -->
                          <li data-index="rs-8" data-transition="random" data-slotamount="7" data-easein="default" data-easeout="default"
                          data-masterspeed="300" data-thumb="http://wedesignthemes.com/themes/lms/wp-content/uploads/revslider/subscription/sub-slider3-bg-100x50.jpg"
                          data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2=""
                          data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8=""
                          data-param9="" data-param10="" data-description="" class="tp-revslider-slidesli" style="width: 100%; height: 100%; overflow: hidden; z-index: 18; visibility: hidden; opacity: 0; background-color: rgba(255, 255, 255, 0);">
                            <!-- MAIN IMAGE -->
                            <div class="slotholder" style="width: 100%; height: 100%; visibility: inherit; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
                              <!--Runtime Modification - Img tag is Still Available for SEO Goals in Source - <img src="http://wedesignthemes.com/themes/lms/wp-content/uploads/revslider/subscription/sub-slider3-bg.jpg" alt="" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg defaultimg" data-no-retina="" height="500" width="780">-->
                              <div class="tp-bgimg defaultimg" style="background-color: transparent; background-repeat: no-repeat; background-image: url(&quot;http://wedesignthemes.com/themes/lms/wp-content/uploads/revslider/subscription/sub-slider3-bg.jpg&quot;); background-size: cover; background-position: center top; width: 100%; height: 100%; opacity: 1; visibility: inherit; z-index: 20;"
                              src="http://wedesignthemes.com/themes/lms/wp-content/uploads/revslider/subscription/sub-slider3-bg.jpg"></div>
                            </div>
                            <!-- LAYERS -->

                            <!-- LAYER NR. 1 -->
                            <div class="tp-parallax-wrap" style="position: absolute; visibility: hidden; left: 380px; top: 259px; z-index: 5;">
                              <div class="tp-loop-wrap" style="position:absolute;">
                                <div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;">
                                  <div class="tp-caption cus_sub_title3   tp-resizeme" id="slide-8-layer-1" data-x="380" data-y="260" data-width="auto"
                                  data-height="auto" data-transform_idle="" data-transform_in="y:-50px;opacity:0;s:1000;e:Power3.easeInOut;"
                                  data-transform_out="auto:auto;s:300;" data-start="1000" data-splitin="none" data-splitout="none"
                                  data-responsive_offset="on" data-end="8400" style="z-index: 5; white-space: nowrap; border-color: rgb(34, 34, 34); visibility: hidden; transition: none 0s ease 0s ; line-height: 22px; border-width: 0px; margin: 0px; padding: 15px 20px 5px; letter-spacing: 0px; font-weight: 500; font-size: 26px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, -49.9px, 0px); transform-origin: 50% 50% 0px;">
                                    <p style="transition: none 0s ease 0s ; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 500; font-size: 26px;">
                                      <span style="transition: none 0s ease 0s ; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 500; font-size: 26px;"> Create a great LMS website </span>                                      </p>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <!-- LAYER NR. 2 -->
                            <div class="tp-parallax-wrap" style="position: absolute; visibility: hidden; left: 380px; top: 318px; z-index: 6;">
                              <div class="tp-loop-wrap" style="position:absolute;">
                                <div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;">
                                  <div class="tp-caption cus_sub_title4   tp-resizeme" id="slide-8-layer-2" data-x="380" data-y="319" data-width="auto"
                                  data-height="auto" data-transform_idle="" data-transform_in="y:50px;opacity:0;s:1000;e:Power3.easeInOut;"
                                  data-transform_out="auto:auto;s:300;" data-start="1000" data-splitin="none" data-splitout="none"
                                  data-responsive_offset="on" data-end="8400" style="z-index: 6; white-space: nowrap; padding: 15px 20px; border-color: rgb(48, 48, 48); visibility: hidden; transition: none 0s ease 0s ; line-height: 26px; border-width: 0px; margin: 0px; letter-spacing: 0px; font-weight: 600; font-size: 16px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: translate3d(0px, 49.9px, 0px); transform-origin: 50% 50% 0px;">Create courses esily using Custom Posts &amp;
                                    <br style="transition: none 0s ease 0s ; line-height: 26px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 600; font-size: 16px;"> Sensei Plugin.
                                  </div>
                                </div>
                              </div>
                            </div>

                            <!-- LAYER NR. 3 -->
                            <div class="tp-parallax-wrap" style="position: absolute; visibility: hidden; left: 380px; top: 395px; z-index: 7;">
                              <div class="tp-loop-wrap" style="position:absolute;">
                                <div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;">
                                  <div class="tp-caption   tp-resizeme" id="slide-8-layer-3" data-x="380" data-y="396" data-width="auto" data-height="auto"
                                  data-transform_idle="" data-transform_in="x:-200px;skX:85px;opacity:0;s:1000;e:Power3.easeInOut;"
                                  data-transform_out="auto:auto;s:300;" data-start="2000" data-splitin="none" data-splitout="none"
                                  data-responsive_offset="on" data-end="8400" style="z-index: 7; white-space: nowrap; visibility: hidden; transition: none 0s ease 0s ; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 14px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 0; transform: matrix3d(1, 0, 0, 0, 0.996195, 0.0871557, 0, 0, 0, 0, 1, 0, -199.6, 0, 0, 1); transform-origin: 50% 50% 0px;"><a href='javascript:alert("click");'
            class="dt-sc-button small filled" style="transition: none 0s ease 0s ; line-height: 22px; border-width: 2px; margin: 10px 0px 0px;
            padding: 13px 20px 11px; letter-spacing: 0px; font-weight: 400; font-size: 14px;">Subscribe Monday Morning</a>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </li>
                          <!-- SLIDE  -->
                          <li data-index="rs-9" data-transition="random" data-slotamount="7" data-easein="default" data-easeout="default"
                          data-masterspeed="300" data-thumb="http://wedesignthemes.com/themes/lms/wp-content/uploads/revslider/subscription/sub-slider1-bg-100x50.jpg"
                          data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2=""
                          data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8=""
                          data-param9="" data-param10="" data-description="" class="tp-revslider-slidesli active-revslide"
                          style="width: 100%; height: 100%; overflow: hidden; z-index: 20; visibility: inherit; opacity: 1; background-color: rgba(255, 255, 255, 0);">
                            <!-- MAIN IMAGE -->
                            <div class="slotholder" style="width: 100%; height: 100%; visibility: inherit; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
                              <!--Runtime Modification - Img tag is Still Available for SEO Goals in Source - <img src="http://wedesignthemes.com/themes/lms/wp-content/uploads/revslider/subscription/sub-slider1-bg.jpg" alt="" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg defaultimg" data-no-retina="" height="500" width="780">-->
                              <div class="tp-bgimg defaultimg" style="background-color: transparent; background-repeat: no-repeat; background-image: url(&quot;http://wedesignthemes.com/themes/lms/wp-content/uploads/revslider/subscription/sub-slider1-bg.jpg&quot;); background-size: cover; background-position: center top; width: 100%; height: 100%; opacity: 1; visibility: inherit; z-index: 20;"
                              src="http://wedesignthemes.com/themes/lms/wp-content/uploads/revslider/subscription/sub-slider1-bg.jpg"></div>
                            </div>
                            <!-- LAYERS -->

                            <!-- LAYER NR. 1 -->
                            <div class="tp-parallax-wrap" style="position: absolute; visibility: visible; left: 76px; top: 98px; z-index: 5;">
                              <div class="tp-loop-wrap" style="position:absolute;">
                                <div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;">
                                  <div class="tp-caption   tp-resizeme" id="slide-9-layer-1" data-x="76" data-y="98" data-width="auto" data-height="auto"
                                  data-transform_idle="" data-transform_in="x:-200px;skX:85px;opacity:0;s:1000;e:Power3.easeInOut;"
                                  data-transform_out="auto:auto;s:300;" data-start="1000" data-responsive_offset="on"
                                  style="z-index: 5; visibility: inherit; transition: none 0s ease 0s ; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 14px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: translate3d(0px, 0px, 0px); transform-origin: 50% 50% 0px;">
					<img src="<?php echo $base_url?>images/sub-slider1-screenshot.png" alt="" data-no-retina="" style="width: 377.244px; height: 213.572px; transition: none 0s ease 0s ; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 14px;"
                                    height="214" width="378">
                                  </div>
                                </div>
                              </div>
                            </div>

                            <!-- LAYER NR. 2 -->
                            <div class="tp-parallax-wrap" style="position: absolute; visibility: visible; left: 499px; top: 119px; z-index: 6;">
                              <div class="tp-loop-wrap" style="position:absolute;">
                                <div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;">
                                  <div class="tp-caption cus_sub_title5   tp-resizeme" id="slide-9-layer-2" data-x="500" data-y="119" data-width="auto"
                                  data-height="auto" data-transform_idle="" data-transform_in="x:right;skX:-85px;s:1000;e:Power3.easeInOut;"
                                  data-transform_out="auto:auto;s:300;" data-start="1500" data-splitin="none" data-splitout="none"
                                  data-responsive_offset="on" style="z-index: 6; white-space: nowrap; border-color: rgb(34, 34, 34); visibility: inherit; transition: none 0s ease 0s ; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 600; font-size: 40px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: translate3d(0px, 0px, 0px); transform-origin: 50% 50% 0px;">
                                    <p style="transition: none 0s ease 0s ; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 600; font-size: 40px;">
                                      <span style="transition: none 0s ease 0s ; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px;
                                      letter-spacing: 0px; font-weight: 600; font-size: 40px;"> 100% </span>                                      </p>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <!-- LAYER NR. 3 -->
                            <div class="tp-parallax-wrap" style="position: absolute; visibility: visible; left: 499px; top: 167px; z-index: 7;">
                              <div class="tp-loop-wrap" style="position:absolute;">
                                <div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;">
                                  <div class="tp-caption cus_sub_title6   tp-resizeme" id="slide-9-layer-3" data-x="500" data-y="167" data-width="auto"
                                  data-height="auto" data-transform_idle="" data-transform_in="x:-200px;skX:85px;opacity:0;s:1000;e:Power3.easeInOut;"
                                  data-transform_out="auto:auto;s:300;" data-start="1500" data-splitin="none" data-splitout="none"
                                  data-responsive_offset="on" style="z-index: 7; white-space: nowrap; border-color: rgb(34, 34, 34); visibility: inherit; transition: none 0s ease 0s ; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 28px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: translate3d(0px, 0px, 0px); transform-origin: 50% 50% 0px;">
                                    <p style="transition: none 0s ease 0s ; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 28px;">
                                      <span style="transition: none 0s ease 0s ; line-height: 22px; border-width: 0px; margin: 0px;
                               
                                padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 28px;"> Certified Courses </span>                                      </p>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <!-- LAYER NR. 4 -->
                            <div class="tp-parallax-wrap" style="position: absolute; visibility: visible; left: 499px; top: 220px; z-index: 8;">
                              <div class="tp-loop-wrap" style="position:absolute;">
                                <div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;">
                                  <div class="tp-caption   tp-resizeme" id="slide-9-layer-4" data-x="500" data-y="220" data-width="auto" data-height="auto"
                                  data-transform_idle="" data-transform_in="x:{-250,250};y:{-150,150};rX:{-90,90};rY:{-90,90};rZ:{-360,360};sX:0;sY:0;opacity:0;s:1000;e:Power3.easeInOut;"
                                  data-transform_out="auto:auto;s:300;" data-start="2500" data-splitin="none" data-splitout="none"
                                  data-responsive_offset="on" style="z-index: 8; white-space: nowrap; visibility: inherit; transition: none 0s ease 0s ; line-height: 22px; border-width: 0px; margin: 0px;
                                  padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 14px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: translate3d(0px, 0px, 0px); transform-origin: 50% 50% 0px;"><a href='javascript:alert("click");' class="dt-sc-button small filled" style="transition: none 0s ease 0s ; line-height: 22px; border-width: 2px; margin: 10px 0px 0px; padding: 13px 20px 11px; letter-spacing: 0px; font-weight: 400; font-size: 14px;">
                                  Subscribe to <br>Monday Morning</a>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </li>
                        </ul>
                        <div class="tp-bannertimer tp-bottom" style="visibility: hidden; width: 78.1%; transform: translate3d(0px, 0px, 0px);"></div>
                        <div class="tp-loader spinner0" style="display: none;">
                          <div class="dot1"></div>
                          <div class="dot2"></div>
                          <div class="bounce1"></div>
                          <div class="bounce2"></div>
                          <div class="bounce3"></div>
                        </div>
                        <div class="tp-bullets persephone horizontal noSwipe" style="width: 52px; height: 14px; top: 100%; transform: matrix(1, 0, 0, 1, -26, -34); left: 50%;">
                          <div class="tp-bullet" style="left: 0px; top: 0px;"></div>
                          <div class="tp-bullet" style="left: 19px; top: 0px;"></div>
                          <div class="tp-bullet selected" style="left: 38px; top: 0px;"></div>
                        </div>
                      </div>
                      <script>
                        var htmlDiv =
                          document.getElementById(
                            "rs-plugin-settings-inline-css"
                          );
                        var
                          htmlDivCss =
                          ".tp-caption.cus_sub_title1,.cus_sub_title1{font-family:\"Raleway\",sans-serif;color:#303030;font-size:26px;line-height:30px;font-weight:600;
                        border - width: 0 px;
                        border - color: rgb(48, 48, 48);
                        border - style: none
                        }
                        .tp - caption.cus_sub_title2,
                          .cus_sub_title2
                          {
                            font - family: \
                              "Raleway\",sans-serif;color:#6b6b6b;font-size:16px;line-height:26px;font-weight:500;border-width:0px;border-color:rgb(107,107,107);border-style:none}.tp-caption.cus_sub_title3,.cus_sub_title3{text-decoration:none;font-family:\"Raleway\",sans-serif;font-size:26px;line-height:normalpx;font-weight:500;padding:15px
                            20 px 5 px
                            20 px;
                            border - width: 0 px;
                            border - color: rgb(34, 34, 34);
                            border - style: none;
                            background: rgba(255, 255, 255,
                              0.9)
                          }.tp - caption.cus_sub_title4,
                          .cus_sub_title4
                          {
                            font - family: \
                              "Raleway\",sans-serif;font-size:16px;line-height:26px;color:#303030;font-weight:600;padding:15px

                            20 px;
                            border - width: 0 px;
                            border - color: rgb(48,
                              48, 48);
                            border - style: none;
                            background: rgba(255,
                              255, 255, 0.9)
                          }.tp - caption.cus_sub_title5,
                          .cus_sub_title5
                          {
                            font - family: \
                              "Raleway\",sans-serif;font-size:40px;font-weight:600;border-width:0px;border-color:rgb(34,34,34);border-style:none;margin:0px}.tp-caption.cus_sub_title6,.cus_sub_title6{font-family:\"Raleway\",sans-serif;font-size:28px;font-weight:400;border-width:0px;border-color:rgb(34,34,34);border-style:none;margin:0px}";

                            if (htmlDiv)
                            {
                              htmlDiv.innerHTML =
                                htmlDiv.innerHTML +
                                htmlDivCss;
                            }
                            else
                            {
                              var htmlDiv =
                                document.createElement(
                                  "div");
                              htmlDiv.innerHTML =
                                "<style>" +
                                htmlDivCss +
                                "</style>";

                              document.getElementsByTagName(
                                "head")[0].appendChild(
                                htmlDiv.childNodes[
                                  0]);

                            }
                      </script>
                      <script type="text/javascript">
                        /******************************************
                                                                                                                                                                -	PREPARE PLACEHOLDER FOR SLIDER	-
                                                                                                                                                        ******************************************/

                        var setREVStartSize = function()
                        {
                          try
                          {
                            var e = new
                            Object, i = jQuery(
                                window).width(),
                              t = 9999, r = 0,
                              n = 0, l = 0, f =
                              0, s = 0, h = 0;
                            e.c = jQuery(
                              '#rev_slider_3_1'
                            );
                            e.gridwidth = [780];
                            e.gridheight = [500];

                            e.sliderLayout =
                              "auto";

                            if (e.responsiveLevels &&
                              (jQuery.each(e.responsiveLevels,
                                  function(
                                    e,
                                    f)
                                  {
                                    f >
                                      i &&
                                      (
                                        t =
                                        r =
                                        f,
                                        l =
                                        e
                                      ),
                                      i >
                                      f &&
                                      f >
                                      r &&
                                      (
                                        r =
                                        f,
                                        n =
                                        e
                                      )
                                  }), t >
                                r && (l = n)
                              ), f = e.gridheight[
                                l] || e.gridheight[
                                0] || e.gridheight,
                              s = e.gridwidth[
                                l] || e.gridwidth[
                                0] || e.gridwidth,
                              h = i / s, h =
                              h > 1 ? 1 : h,
                              f = Math.round(
                                h * f),
                              "fullscreen" ==
                              e.sliderLayout)
                            {
                              var
                                u = (e.c.width(),
                                  jQuery(
                                    window
                                  ).height()
                                );
                              if (void 0 != e
                                .fullScreenOffsetContainer
                              )
                              {
                                var
                                  c = e.fullScreenOffsetContainer
                                  .split(
                                    ","
                                  );
                                if (c)
                                  jQuery.each(
                                    c,
                                    function(
                                      e,
                                      i
                                    )
                                    {
                                      u
                                        =
                                        jQuery(
                                          i
                                        )
                                        .length >
                                        0 ?
                                        u -
                                        jQuery(
                                          i
                                        )
                                        .outerHeight(!
                                          0
                                        ) :
                                        u
                                    }),
                                  e.fullScreenOffset
                                  .split(
                                    "%"
                                  ).length >
                                  1 &&
                                  void

                                0 != e.fullScreenOffset &&
                                  e.fullScreenOffset
                                  .length >
                                  0 ? u -=
                                  jQuery(
                                    window
                                  ).height() *
                                  parseInt(
                                    e.fullScreenOffset,
                                    0) /
                                  100 :
                                  void

                                0 != e.fullScreenOffset &&
                                  e.fullScreenOffset
                                  .length >
                                  0 && (u -=
                                    parseInt(
                                      e
                                      .fullScreenOffset,
                                      0
                                    ))
                              }
                              f = u
                            }
                            else
                              void
                            0 != e.minHeight &&
                              f < e.minHeight &&
                              (f = e.minHeight);
                            e.c.closest(
                              ".rev_slider_wrapper"
                            ).css(
                            {
                              height: f
                            })

                          }
                          catch (d)
                          {
                            console.log(
                              "Failure at Presize of Slider:" +
                              d)
                          }
                        };

                        setREVStartSize();

                        function revslider_showDoubleJqueryError
                          (sliderID)
                          {
                            var errorMessage =
                              "Revolution Slider Error: You have some 
                            jquery.js library include that comes after the revolution files js
                            include.
                            ";
                            errorMessage +=
                              "<br> This includes make eliminates the revolution 
                            slider libraries, and make it not work
                              .
                            ";
                            errorMessage +=
                              "<br><br> To fix it you can:<br>&nbsp;&nbsp;&nbsp; 
                            1. In the Slider Settings
                              - > Troubleshooting set option:
                              < strong > < b >
                              Put
                            JS Includes To Body <
                              /b></strong >
                              option to true.
                            ";
                            errorMessage +=
                              "<br>&nbsp;&nbsp;&nbsp; 2. Find the double 
                            jquery.js include and remove it
                              .
                            ";
                            errorMessage =
                              "<span style='font-size:16px;color:#BC0C06;'>" +
                              errorMessage +
                              "</span>";
                            jQuery(sliderID).show()
                              .html(errorMessage);
                          }
                        var tpj = jQuery;
                        tpj.noConflict();
                        var revapi3;
                        tpj(document).ready(function()
                        {
                          if (tpj(
                              "#rev_slider_3_1"
                            ).revolution ==
                            undefined)
                          {
                            revslider_showDoubleJqueryError
                              (
                                "#rev_slider_3_1"
                              );
                          }
                          else
                          {
                            revapi3 = tpj(
                              "#rev_slider_3_1"
                            ).show().revolution(
                            {
                              sliderType: "standard",
                              jsFileLocation: "//wedesignthemes.com/themes/lms/wp-content/plugins/revslider/public/assets/js/",

                              sliderLayout: "auto",
                              dottedOverlay: "none",
                              delay: 9000,
                              navigation:
                              {
                                keyboardNavigation: "off",
                                keyboard_direction: "horizontal",
                                mouseScrollNavigation: "off",
                                onHoverStop: "on",
                                touch:
                                {
                                  touchenabled: "on",
                                  swipe_threshold: 0.7,
                                  swipe_min_touches: 1,
                                  swipe_direction: "horizontal",
                                  drag_block_vertical: false
                                },
                                bullets:
                                {
                                  enable: true,
                                  hide_onmobile: false,
                                  style: "persephone",
                                  hide_onleave: false,
                                  direction: "horizontal",
                                  h_align: "center",
                                  v_align: "bottom",
                                  h_offset: 0,
                                  v_offset: 20,
                                  space: 5,
                                  tmp: ''
                                }
                              },
                              visibilityLevels: [
                                1240,
                                1024,
                                778,
                                480
                              ],
                              gridwidth: 780,
                              gridheight: 500,
                              lazyType: "none",
                              shadow: 0,
                              spinner: "spinner0",
                              stopLoop: "off",
                              stopAfterLoops:
                                -
                                1,
                              stopAtSlide:
                                -
                                1,
                              shuffle: "off",
                              autoHeight: "off",
                              disableProgressBar: "on",
                              hideThumbsOnMobile: "off",
                              hideSliderAtLimit: 0,
                              hideCaptionAtLimit: 0,
                              hideAllCaptionAtLilmit: 0,
                              debugMode: false,
                              fallbacks:
                              {
                                simplifyAll: "off",
                                nextSlideOnWindowFocus: "off",
                                disableFocusListener: false,
                              }
                            });
                          }
                        }); /*ready*/
                      </script>
                      <script>
                        var htmlDivCss =
                          unescape(
                            ".persephone.tp-bullets%20%7B%0A%7D%0A.persephone.tp-bullets%3Abefore%20%7B%0A%09content%3A%22%20%22%3B%0A%09position%3Aabsolute%3B%0A%09width%3A100%25%3B%0A%09height%3A100%25%3B%0A%09background%3A%23transparent%3B%0A%09padding%3A10px%3B%0A%09margin-left%3A-10px%3Bmargin-top%3A-10px%3B%0A%09box-sizing%3Acontent-box%3B%0A%7D%0A.persephone%20.tp-bullet%20%7B%0A%09width%3A12px%3B%0A%09height%3A12px%3B%0A%09position%3Aabsolute%3B%0A%09background%3A%23aaa%3B%0A%09border%3A1px%20solid%20%23e5e5e5%3B%09%0A%09cursor%3A%20pointer%3B%0A%09box-sizing%3Acontent-box%3B%0A%7D%0A.persephone%20.tp-bullet%3Ahover%2C%0A.persephone%20.tp-bullet.selected%20%7B%0A%09background%3A%23222%3B%0A%7D%0A.persephone%20.tp-bullet-image%20%7B%0A%7D%0A.persephone%20.tp-bullet-title%20%7B%0A%7D%0A%0A"
                          );

                        var htmlDiv =
                          document.getElementById(
                            'rs-plugin-settings-inline-css'
                          );
                        if (htmlDiv)
                        {
                          htmlDiv.innerHTML = htmlDiv
                            .innerHTML + htmlDivCss;
                        }
                        else
                        {
                          var htmlDiv = document.createElement(
                            'div');
                          htmlDiv.innerHTML =
                            '<style>' + htmlDivCss +
                            '</style>';

                          document.getElementsByTagName(
                            'head')[0].appendChild(
                            htmlDiv.childNodes[
                              0]);

                        }
                      </script>
                    </div>
                    <!-- END REVOLUTION SLIDER -->
                  </div>
                </div>
                <div class="column dt-sc-one-third no-space">

                  <div class="dt-sc-subscription-frm-container">
                    <h2> <i class="fa fa-clock-o"> </i> Sign Up </h2>
                    <div class="dt-sc-clear"></div>
                    <form name="frmsubscription" action="<?php echo base_url()?>sign-up" class="dt-sc-subscription-frm" method="post">
			<input placeholder="Full Name (required)" name="fullname" required type="text">
			<input placeholder="Email (required)" name="user_email" required type="email">
			<input placeholder="AGE (required)" name="age" required type="text">
			<input placeholder="Highest Qualification (required)" name="dtemail" required="" type="text">
                        <button type="submit" class="dt-sc-button" value="Submit" name="user_sign_up" id="usersignup">Submit</button>
                     
                    </form>
                    <div class="dt-sc-subscription-enquiry"> <i class="fa fa-phone"> </i> <span> Inquiries </span> 0123456789 </div>
                  </div>

                </div>
              </div>
            </div>
            <div class="dt-sc-hr-invisible  "></div>


            <section id="primary" class="content-full-width">
              <!-- #post-5009 -->
              <div id="post-5009" class="post-5009 page type-page status-publish hentry">
                <div class="fullwidth-section  ">
                  <div class="container">
                    <div class="dt-sc-hr-invisible-medium  "></div>
                     <div class="column dt-sc-one-fifth  space  first">
                      <div class="dt-sc-ico-content type14">
                        <div class="custom-icon"><a href="#" target="_blank"><span class="fa fa-custom-icon1"></span></a>
                        </div>
                        <h4><a href="#" target="_blank"> Do Your Self</a></h4>
                      </div>
                    </div>
                    <div class="column dt-sc-one-fifth  space ">
                      <div class="dt-sc-ico-content type14">
                        <div class="custom-icon"><a href="#" target="_blank"><span class="	fa fa-line-chart"></span></a>
                        </div>
                        <h4><a href="#" target="_blank"> MM Dashboard </a></h4>
                      </div>
                    </div>
                  
                    <div class="column dt-sc-one-fifth  space  ">
                      <div class="dt-sc-ico-content type14">
                        <div class="custom-icon"><a href="#" target="_blank"><span class="fa fa-custom-icon3"></span></a>
                        </div>
                        <h4><a href="#" target="_blank"> Grade Your Skill </a></h4>
                      </div>
                    </div>
                    <div class="column dt-sc-one-fifth  space  ">
                      <div class="dt-sc-ico-content type14">
                        <div class="custom-icon"><a href="#" target="_blank"><span class="fa fa-user"></span></a>
                        </div>
                        <h4><a href="#" target="_blank"> JObs </a></h4>
                      </div>
                    </div>
                      <div class="column dt-sc-one-fifth  space  ">
                      <div class="dt-sc-ico-content type14">
                        <div class="custom-icon"><a href="#" target="_blank"><span class="fa fa-superpowers"></span></a>
                        </div>
                        <h4><a href="#" target="_blank">Intellectual Property </a></h4>
                      </div>
                    </div>
                    <div class="dt-sc-hr-invisible-medium  "></div>
                    <h2 class="border-title  ">What is Monday Morning?<span></span></h2>
                    <div class="column dt-sc-one-third  space  first">
                      <h3> Monday Morning</h3>
                      <p>Student Registration and Administration Monday Morning sit atur
                        Skill  and increase your Knowledge, sed Monday Morning is best  consequuntur magni res Monday Morning qui ratione voluptatem Monday Morning nesciunt.</p>
                      <div class="dt-sc-hr-invisible-small  "></div>
                      <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered
                        alteration in some form, by injected humour, or randomised believable.</p>
                      <div class="dt-sc-hr-invisible-small  "></div>
                      <a href="#" target="_blank" class="dt-sc-button   small  ">View All Courses</a>
                    </div>
                    <div class="column dt-sc-two-third  space  ">
                      <div class="dt-sc-course-carousel-wrapper">
                        <div class="caroufredsel_wrapper" style="display: block; text-align: start; float: none; position: relative; top: auto; right: auto; bottom: auto; left: auto; z-index: auto; width: 792px; height: 520px; margin: 0px 0px 20px; overflow: hidden;">
                          <ul class="dt-sc-course-carousel" data-column="2" style="text-align: left; float: none; position: absolute; top: 0px; right: auto; bottom: auto; left: 0px; margin: 0px; width: 5544px; height: 520px;">
                            <li class="column dt-sc-one-half" style="width: 376px;">
                              <article id="post-5993" class="dt-sc-custom-course-type  post-5993 dt_courses type-dt_courses status-publish has-post-thumbnail hentry course_category-education">
                                <div class="dt-sc-course-thumb">
                                  <a href="#">
                                    <img src="images/course13-573x403.jpg"
                                    height="403" width="573">
                                  </a>
                                  <div class="dt-sc-course-overlay">
                                    <a title="Power Electronics" href="#"
                                       class="dt-sc-button small white">View Course</a>
                                  </div>
                                </div>
                                <div class="dt-sc-course-details"><span class="dt-sc-course-price"><span class="amount">$50</span></span>
                                  <h5><a href="#" title="Power Electronics">Power Electronics</a></h5>
                                  <div class="dt-sc-course-meta">
                                    <p> <a href="#" rel="tag">Education</a>                                      </p>
                                    <p>6&nbsp;Lessons</p>
                                  </div>
                                  <div class="dt-sc-course-data">
                                    <div class="dt-sc-course-duration">
                                      <i class="fa fa-clock-o"> </i>
                                      <span>05 : 35</span>
                                    </div><span id="post-ratings-5993" class="post-ratings" itemscope="" itemtype="http://schema.org/Article"
                                    data-nonce="602895018a"><img id="rating_5993_1" src="images/rating_on.gif" alt="1 Star" title="1 Star" onmouseover="current_rating(5993, 1, '1 Star');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5993_2" src="images/rating_on.gif" alt="2 Stars" title="2 Stars" onmouseover="current_rating(5993, 2, '2 Stars');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5993_3" src="images/rating_on.gif" alt="3 Stars" title="3 Stars" onmouseover="current_rating(5993, 3, '3 Stars');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5993_4" src="images/rating_on.gif" alt="4 Stars" title="4 Stars" onmouseover="current_rating(5993, 4, '4 Stars');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5993_5" src="images/rating_off.gif" alt="5 Stars" title="5 Stars" onmouseover="current_rating(5993, 5, '5 Stars');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"> (<strong>271</strong> votes, average: <strong>4.17</strong> out of 5)<span class="post-ratings-text" id="ratings_5993_text"></span>
                                    <meta itemprop="headline" content="Power Electronics">
                                    <meta itemprop="description" content="Ut ac euismod velit. Aliquam condimentum dolor accumsan, venenatis sapien eu, egestas nunc. Suspendisse euismod semper fermentum. Nulla eleifend nibh pretium mattis dapibus.">
                                    <meta itemprop="datePublished" content="2014-08-11T04:21:43+00:00">
                                    <meta itemprop="url" content="#">
                                    <meta itemprop="image" content="#">
                                    <div style="display: none;" itemprop="aggregateRating" itemscope="" itemtype="http://schema.org/AggregateRating">
                                      <meta itemprop="bestRating" content="5">
                                      <meta itemprop="worstRating" content="1">
                                      <meta itemprop="ratingValue" content="4.17">
                                      <meta itemprop="ratingCount" content="271">
                                    </div>
                                    </span><span id="post-ratings-5993-loading" class="post-ratings-loading">
			<img src="images/loading.gif" class="post-ratings-image" height="16" width="16">Loading...</span>
                                  </div>
                                </div>
                              </article>
                            </li>
                            <li class="column dt-sc-one-half" style="width: 376px;">
                              <article id="post-5992" class="dt-sc-custom-course-type  post-5992 dt_courses type-dt_courses status-publish has-post-thumbnail hentry course_category-mathematics">
                                <div class="dt-sc-course-thumb">
                                  <a href="#>
                                    <img src="images/course14-573x403.jpg" height="403" width="573" />
                                  </a>
                                  <div class="dt-sc-course-overlay">
                                    <a title="Introduction to Calculus" href="h#"
                                    class="dt-sc-button small white">View Course</a>
                                  </div>
                                </div>
                                <div class="dt-sc-course-details"><span class="dt-sc-course-price"><span class="amount">Free</span></span>
                                  <h5><a href="#" title="Introduction to Calculus">Introduction to Calculus</a></h5>
                                  <div class="dt-sc-course-meta">
                                    <p> <a href="#"
                                      rel="tag">Mathematics</a> </p>
                                    <p>5&nbsp;Lessons</p>
                                  </div>
                                  <div class="dt-sc-course-data">
                                    <div class="dt-sc-course-duration">
                                      <i class="fa fa-clock-o"> </i>
                                      <span>03 : 15</span>
                                    </div><span id="post-ratings-5992" class="post-ratings" itemscope="" itemtype="http://schema.org/Article"
                                    data-nonce="548be202f6"><img id="rating_5992_1" src="images/rating_on.gif" alt="1 Star" title="1 Star" onmouseover="current_rating(5992, 1, '1 Star');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5992_2" src="images/rating_on.gif" alt="2 Stars" title="2 Stars" onmouseover="current_rating(5992, 2, '2 Stars');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5992_3" src="images/rating_on.gif" alt="3 Stars" title="3 Stars" onmouseover="current_rating(5992, 3, '3 Stars');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5992_4" src="images/rating_on.gif" alt="4 Stars" title="4 Stars" onmouseover="current_rating(5992, 4, '4 Stars');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5992_5" src="images/rating_off.gif" alt="5 Stars" title="5 Stars" onmouseover="current_rating(5992, 5, '5 Stars');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"> (<strong>263</strong> votes, average: <strong>4.16</strong> out of 5)<span class="post-ratings-text" id="ratings_5992_text"></span>
                                    <meta itemprop="headline" content="Introduction to Calculus">
                                    <meta itemprop="description" content="Fusce commodo in neque vitae mollis. Sed dolor lorem, cursus et venenatis sed, sodales eu nisi. Nunc lacinia massa neque, eu tincidunt mi blandit eget. ">
                                    <meta itemprop="datePublished" content="2014-08-11T04:18:26+00:00">
                                    <meta itemprop="url" content="#">
                                    <meta itemprop="image" content="#">
                                    <div style="display: none;" itemprop="aggregateRating" itemscope="" itemtype="http://schema.org/AggregateRating">
                                      <meta itemprop="bestRating" content="5">
                                      <meta itemprop="worstRating" content="1">
                                      <meta itemprop="ratingValue" content="4.16">
                                      <meta itemprop="ratingCount" content="263">
                                    </div>
                                    </span><span id="post-ratings-5992-loading" class="post-ratings-loading">
			<img src="images/loading.gif" class="post-ratings-image" height="16" width="16">Loading...</span>
                                  </div>
                                </div>
                              </article>
                            </li>
                            <li class="column dt-sc-one-half" style="width: 376px;">
                              <article id="post-5991" class="dt-sc-custom-course-type  post-5991 dt_courses type-dt_courses status-publish has-post-thumbnail hentry course_category-law">
                                <div class="dt-sc-course-thumb">
                                  <a href=''><img src="images/course15-573x403.jpg"
                                    height="403" width="573">
                                  </a>
                                  <div class="dt-sc-course-overlay">
                                    <a title="Basic Laws and Policies" href="#"
                                    class="dt-sc-button small white">View Course</a>
                                  </div>
                                </div>
                                <div class="dt-sc-course-details"><span class="dt-sc-course-price"><span class="amount">$40</span></span>
                                  <h5><a href="#" title="Basic Laws and Policies">Basic Laws and Policies</a></h5>
                                  <div class="dt-sc-course-meta">
                                    <p> <a href="#" rel="tag">Law</a>                                      </p>
                                    <p>5&nbsp;Lessons</p>
                                  </div>
                                  <div class="dt-sc-course-data">
                                    <div class="dt-sc-course-duration">
                                      <i class="fa fa-clock-o"> </i>
                                      <span>05 : 10</span>
                                    </div><span id="post-ratings-5991" class="post-ratings" itemscope="" itemtype="http://schema.org/Article"
                                    data-nonce="8bb0fe2c9a"><img id="rating_5991_1" src="images/rating_on.gif" alt="1 Star" title="1 Star" onmouseover="current_rating(5991, 1, '1 Star');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5991_2" src="images/rating_on.gif" alt="2 Stars" title="2 Stars" onmouseover="current_rating(5991, 2, '2 Stars');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5991_3" src="images/rating_on.gif" alt="3 Stars" title="3 Stars" onmouseover="current_rating(5991, 3, '3 Stars');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5991_4" src="images/rating_on.gif" alt="4 Stars" title="4 Stars" onmouseover="current_rating(5991, 4, '4 Stars');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5991_5" src="images/rating_off.gif" alt="5 Stars" title="5 Stars" onmouseover="current_rating(5991, 5, '5 Stars');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"> (<strong>112</strong> votes, average: <strong>4.16</strong> out of 5)<span class="post-ratings-text" id="ratings_5991_text"></span>
                                    <meta itemprop="headline" content="Basic Laws and Policies">
                                    <meta itemprop="description" content="Pellentesque venenatis orci vel enim malesuada, eget dignissim turpis egestas. Donec a ligula ac tellus ultrices lacinia. Nullam non nisi varius, posuere leo non, scelerisque orci.">
                                    <meta itemprop="datePublished" content="2014-08-11T04:16:14+00:00">
                                    <meta itemprop="url" content="#">
                                    <meta itemprop="image" content="#">
                                    <div style="display: none;" itemprop="aggregateRating" itemscope="" itemtype="http://schema.org/AggregateRating">
                                      <meta itemprop="bestRating" content="5">
                                      <meta itemprop="worstRating" content="1">
                                      <meta itemprop="ratingValue" content="4.16">
                                      <meta itemprop="ratingCount" content="112">
                                    </div>
                                    </span><span id="post-ratings-5991-loading" class="post-ratings-loading">
			<img src="images/loading.gif" class="post-ratings-image" height="16" width="16">Loading...</span>
                                  </div>
                                </div>
                              </article>
                            </li>
                            <li class="column dt-sc-one-half" style="width: 376px;">
                              <article id="post-5990" class="dt-sc-custom-course-type  post-5990 dt_courses type-dt_courses status-publish has-post-thumbnail hentry course_category-health">
                                <div class="dt-sc-course-thumb">
                                  <a href="#"><img src="images/course16-573x403.jpg"
                                    height="403" width="573">
                                  </a>
                                  <div class="dt-sc-course-overlay">
                                    <a title="Healthcare Delivery" href="#" class="dt-sc-button small white">View Course</a>
                                  </div>
                                </div>
                                <div class="dt-sc-course-details"><span class="dt-sc-course-price"><span class="amount">$50</span></span>
                                  <h5><a href="#" title="Healthcare Delivery">Healthcare Delivery</a></h5>
                                  <div class="dt-sc-course-meta">
                                    <p> <a href="#" rel="tag">Health</a>                                      </p>
                                    <p>4&nbsp;Lessons</p>
                                  </div>
                                  <div class="dt-sc-course-data">
                                    <div class="dt-sc-course-duration">
                                      <i class="fa fa-clock-o"> </i>
                                      <span>03 : 25</span>
                                    </div><span id="post-ratings-5990" class="post-ratings" itemscope="" itemtype="http://schema.org/Article"
                                    data-nonce="54d73e60f6"><img id="rating_5990_1" src="images/rating_on.gif" alt="1 Star" title="1 Star" onmouseover="current_rating(5990, 1, '1 Star');" onmouseout="ratings_off(4.1, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5990_2" src="images/rating_on.gif" alt="2 Stars" title="2 Stars" onmouseover="current_rating(5990, 2, '2 Stars');" onmouseout="ratings_off(4.1, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5990_3" src="images/rating_on.gif" alt="3 Stars" title="3 Stars" onmouseover="current_rating(5990, 3, '3 Stars');" onmouseout="ratings_off(4.1, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5990_4" src="images/rating_on.gif" alt="4 Stars" title="4 Stars" onmouseover="current_rating(5990, 4, '4 Stars');" onmouseout="ratings_off(4.1, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5990_5" src="images/rating_off.gif" alt="5 Stars" title="5 Stars" onmouseover="current_rating(5990, 5, '5 Stars');" onmouseout="ratings_off(4.1, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"> (<strong>64</strong> votes, average: <strong>4.08</strong> out of 5)<span class="post-ratings-text" id="ratings_5990_text"></span>
                                    <meta itemprop="headline" content="Healthcare Delivery">
                                    <meta itemprop="description" content="In bibendum eu justo vitae ornare. In et tellus ut magna vehicula ultricies. Duis blandit adipiscing dolor, ut tincidunt augue tincidunt eu. Duis non auctor enim.">
                                    <meta itemprop="datePublished" content="2014-08-11T04:13:36+00:00">
                                    <meta itemprop="url" content="#">
                                    <meta itemprop="image" content="#">
                                    <div style="display: none;" itemprop="aggregateRating" itemscope="" itemtype="http://schema.org/AggregateRating">
                                      <meta itemprop="bestRating" content="5">
                                      <meta itemprop="worstRating" content="1">
                                      <meta itemprop="ratingValue" content="4.08">
                                      <meta itemprop="ratingCount" content="64">
                                    </div>
                                    </span><span id="post-ratings-5990-loading" class="post-ratings-loading">
			<img src="images/loading.gif" class="post-ratings-image" height="16" width="16">Loading...</span>
                                  </div>
                                </div>
                              </article>
                            </li>
                            <li class="column dt-sc-one-half" style="width: 376px;">
                              <article id="post-5989" class="dt-sc-custom-course-type  post-5989 dt_courses type-dt_courses status-publish has-post-thumbnail hentry course_category-law">
                                <div class="dt-sc-course-thumb">
                                  <a href="#"><img src="images/course17-573x403.jpg"
                                    height="403" width="573">
                                  </a>
                                  <div class="dt-sc-course-overlay">
                                    <a title="General Business Law" href="#" class="dt-sc-button small white">View Course</a>
                                  </div>
                                </div>
                                <div class="dt-sc-course-details"><span class="dt-sc-course-price"><span class="amount">Free</span></span>
                                  <h5><a href="#" title="General Business Law">General Business Law</a></h5>
                                  <div class="dt-sc-course-meta">
                                    <p> <a href="#" rel="tag">Law</a>                                      </p>
                                    <p>7&nbsp;Lessons</p>
                                  </div>
                                  <div class="dt-sc-course-data">
                                    <div class="dt-sc-course-duration">
                                      <i class="fa fa-clock-o"> </i>
                                      <span>06 : 05</span>
                                    </div><span id="post-ratings-5989" class="post-ratings" itemscope="" itemtype="http://schema.org/Article"
                                    data-nonce="bcf49dbcdc"><img id="rating_5989_1" src="images/rating_on.gif" alt="1 Star" title="1 Star" onmouseover="current_rating(5989, 1, '1 Star');" onmouseout="ratings_off(4.1, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5989_2" src="images/rating_on.gif" alt="2 Stars" title="2 Stars" onmouseover="current_rating(5989, 2, '2 Stars');" onmouseout="ratings_off(4.1, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5989_3" src="images/rating_on.gif" alt="3 Stars" title="3 Stars" onmouseover="current_rating(5989, 3, '3 Stars');" onmouseout="ratings_off(4.1, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5989_4" src="images/rating_on.gif" alt="4 Stars" title="4 Stars" onmouseover="current_rating(5989, 4, '4 Stars');" onmouseout="ratings_off(4.1, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5989_5" src="images/rating_off.gif" alt="5 Stars" title="5 Stars" onmouseover="current_rating(5989, 5, '5 Stars');" onmouseout="ratings_off(4.1, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"> (<strong>81</strong> votes, average: <strong>4.10</strong> out of 5)<span class="post-ratings-text" id="ratings_5989_text"></span>
                                    <meta itemprop="headline" content="General Business Law">
                                    <meta itemprop="description" content="Fusce commodo in neque vitae mollis. Sed dolor lorem, cursus et venenatis sed, sodales eu nisi. Nunc lacinia massa neque, eu tincidunt mi blandit eget.">
                                    <meta itemprop="datePublished" content="2014-08-11T04:11:30+00:00">
                                    <meta itemprop="url" content="#">
                                    <meta itemprop="image" content="#">
                                    <div style="display: none;" itemprop="aggregateRating" itemscope="" itemtype="http://schema.org/AggregateRating">
                                      <meta itemprop="bestRating" content="5">
                                      <meta itemprop="worstRating" content="1">
                                      <meta itemprop="ratingValue" content="4.1">
                                      <meta itemprop="ratingCount" content="81">
                                    </div>
                                    </span><span id="post-ratings-5989-loading" class="post-ratings-loading">
			<img src="images/loading.gif" class="post-ratings-image" height="16" width="16">Loading...</span>
                                  </div>
                                </div>
                              </article>
                            </li>
                            <li class="column dt-sc-one-half" style="width: 376px;">
                              <article id="post-5988" class="dt-sc-custom-course-type  post-5988 dt_courses type-dt_courses status-publish has-post-thumbnail hentry course_category-engineering">
                                <div class="dt-sc-course-thumb">
                                  <a href="http://wedesignthemes.com/themes/lms/courses/emerging-trends-and-technologies/"><img src="images/course18-573x403.jpg"
                                    height="403" width="573">
                                  </a>
                                  <div class="dt-sc-course-overlay">
                                    <a title="Emerging Trends and Technologies" href="http://wedesignthemes.com/themes/lms/courses/emerging-trends-and-technologies/"
                                    class="dt-sc-button small white">View Course</a>
                                  </div>
                                </div>
                                <div class="dt-sc-course-details"><span class="dt-sc-course-price"><span class="amount">Free</span></span>
                                  <h5><a href="http://wedesignthemes.com/themes/lms/courses/emerging-trends-and-technologies/" title="Emerging Trends and Technologies">Emerging Trends and Technologies</a></h5>
                                  <div class="dt-sc-course-meta">
                                    <p> <a href="http://wedesignthemes.com/themes/lms/coursecategory/engineering/"
                                      rel="tag">Engineering</a> </p>
                                    <p>4&nbsp;Lessons</p>
                                  </div>
                                  <div class="dt-sc-course-data">
                                    <div class="dt-sc-course-duration">
                                      <i class="fa fa-clock-o"> </i>
                                      <span>03 : 10</span>
                                    </div><span id="post-ratings-5988" class="post-ratings" itemscope="" itemtype="http://schema.org/Article"
                                    data-nonce="e5f6850de9"><img id="rating_5988_1" src="images/rating_on.gif" alt="1 Star" title="1 Star" onmouseover="current_rating(5988, 1, '1 Star');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5988_2" src="images/rating_on.gif" alt="2 Stars" title="2 Stars" onmouseover="current_rating(5988, 2, '2 Stars');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5988_3" src="images/rating_on.gif" alt="3 Stars" title="3 Stars" onmouseover="current_rating(5988, 3, '3 Stars');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5988_4" src="images/rating_on.gif" alt="4 Stars" title="4 Stars" onmouseover="current_rating(5988, 4, '4 Stars');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"><img id="rating_5988_5" src="images/rating_off.gif" alt="5 Stars" title="5 Stars" onmouseover="current_rating(5988, 5, '5 Stars');" onmouseout="ratings_off(4.2, 0, 0);" onclick="rate_post();" onkeypress="rate_post();" style="cursor: pointer; border: 0px;"> (<strong>58</strong> votes, average: <strong>4.19</strong> out of 5)<span class="post-ratings-text" id="ratings_5988_text"></span>
                                    <meta itemprop="headline" content="Emerging Trends and Technologies">
                                    <meta itemprop="description" content="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut cursus magna nisi, vel pharetra ligula cursus eu. Sed ultricies condimentum velit et pharetra.">
                                    <meta itemprop="datePublished" content="2014-08-11T04:07:30+00:00">
                                    <meta itemprop="url" content="http://wedesignthemes.com/themes/lms/courses/emerging-trends-and-technologies/">
                                    <meta itemprop="image" content="http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/course18-150x150.jpg">
                                    <div style="display: none;" itemprop="aggregateRating" itemscope="" itemtype="http://schema.org/AggregateRating">
                                      <meta itemprop="bestRating" content="5">
                                      <meta itemprop="worstRating" content="1">
                                      <meta itemprop="ratingValue" content="4.19">
                                      <meta itemprop="ratingCount" content="58">
                                    </div>
                                    </span><span id="post-ratings-5988-loading" class="post-ratings-loading">
			<img src="images/loading.gif" class="post-ratings-image" height="16" width="16">Loading...</span>
                                  </div>
                                </div>
                              </article>
                            </li>
                          </ul>
                        </div>
                        <div class="carousel-arrows">
                          <a class="course-prev" href="" style="display: block;"></a>
                          <a class="course-next" href="" style="display: block;"></a>
                        </div>
                      </div>
                    </div>
                    <div class="dt-sc-hr-invisible-medium  "></div>
                    <div class="dt-sc-hr-invisible-small  "></div>
                    <div class="column dt-sc-one-third  space  first">
                      <p><img class="size-full wp-image-4762" src="images/lms-banner1.jpg"
                        alt="ad1" height="210" width="420">
                      </p>
                    </div>
                    <div class="column dt-sc-one-third  space  ">
                      <p><img class="size-full wp-image-4763" src="images/lms-banner2.jpg"
                        alt="ad2" height="210" width="420">
                      </p>
                    </div>
                    <div class="column dt-sc-one-third  space  ">
                      <p><img class="size-full wp-image-4764" src="images/lms-banner3.jpg"
                        alt="ad3" height="210" width="420">
                      </p>
                    </div>
                    <div class="dt-sc-hr-invisible-medium  "></div>
                    <h2 class="border-title aligncenter ">Blog<span></span></h2>
                    <div class="column dt-sc-one-third first">
                      <article class="blog-entry no-border post-486 post type-post status-publish format-image has-post-thumbnail hentry category-post-format-audio category-photoshop tag-creative tag-design tag-news-2 post_format-post-format-image">
                        <div class="blog-entry-inner">
                          <div class="entry-thumb">
                            <a href="http://wedesignthemes.com/themes/lms/blog/image-minus-id-quod/"><img src="images/blog15-420x295.jpg"
                              class="attachment-blogcourse-three-column-single-sidebar size-blogcourse-three-column-single-sidebar wp-post-image"
                              alt="blog15" srcset="http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-420x295.jpg 420w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-300x211.jpg 300w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-1024x719.jpg 1024w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-100x70.jpg 100w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15.jpg 1170w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-880x618.jpg 880w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-590x415.jpg 590w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-573x403.jpg 573w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-429x302.jpg 429w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog15-431x303.jpg 431w"
                              sizes="(max-width: 420px) 100vw, 420px" height="295" width="420">
                            </a>
                            <div class="entry-thumb-desc">
                              <p>There are many variations of passages of Lorem Ipsum...</p>
                            </div>
                          </div>
                          <!-- .entry-thumb -->
                          <div class="entry-details">
                            <div class="featured-post"> <span class="fa fa-trophy"> </span> <span class="text">Featured</span>
                            </div>
                            <div class="entry-meta">
                              <div class="date">28 Jan </div>
                              <a href="http://wedesignthemes.com/themes/lms/blog/image-minus-id-quod/" class="entry_format"></a>
                            </div>
                            <div class="entry-title">
                              <h4><a href="http://wedesignthemes.com/themes/lms/blog/image-minus-id-quod/">Image - Minus id quod</a></h4>
                            </div>
                            <div class="entry-metadata">
                              <p class="author"><i class="fa fa-user"> </i> <a href="http://wedesignthemes.com/themes/lms/blog/author/ram/">ram</a>
                              </p><span> | </span>
                              <p class="tags"><i class="fa fa-tags"> </i><a href="http://wedesignthemes.com/themes/lms/blog/tag/creative/"> creative</a>,
                                <a href="http://wedesignthemes.com/themes/lms/blog/tag/design/"> design</a>,
                                <a href="http://wedesignthemes.com/themes/lms/blog/tag/news-2/"> news</a>
                              </p>
                              <span> | </span>
                              <p class="comments"><a href="http://wedesignthemes.com/themes/lms/blog/image-minus-id-quod//#respond"
                                class="comments"><span class="fa fa-comments"> </span> 0</a>
                              </p>
                            </div>
                          </div>
                        </div>
                      </article>
                    </div>
                    <div class="column dt-sc-one-third">
                      <article class="blog-entry no-border post-484 post type-post status-publish format-gallery has-post-thumbnail hentry category-post-format-audio category-news category-photoshop tag-blog-2 tag-chat post_format-post-format-gallery">
                        <div class="blog-entry-inner">
                          <div class="entry-thumb">
                            <div class="bx-wrapper" style="max-width: 100%; margin: 0px auto;">
                              <div class="bx-viewport" style="width: 100%; overflow: hidden; position: relative; height: 277px;">
                                <ul class="entry-gallery-post-slider" style="width: 615%; position: relative; left: -394px;">
                                  <li style="float: left; list-style: outside none none; position: relative; width: 394px;" class="bx-clone">
                                    <img src="images/blog6-420x295.jpg"
                                    height="295" width="420">
                                  </li>
                                  <li style="float: left; list-style: outside none none; position: relative; width: 394px;"><img src="images/blog16-420x295.jpg"
                                    height="295" width="420">
                                  </li>
                                  <li style="float: left; list-style: outside none none; position: relative; width: 394px;"><img src="images/blog14-420x295.jpg"
                                    height="295" width="420">
                                  </li>
                                  <li style="float: left; list-style: outside none none; position: relative; width: 394px;"><img src="images/blog4-420x295.jpg"
                                    height="295" width="420">
                                  </li>
                                  <li style="float: left; list-style: outside none none; position: relative; width: 394px;"><img src="images/blog6-420x295.jpg"
                                    height="295" width="420">
                                  </li>
                                  <li style="float: left; list-style: outside none none; position: relative; width: 394px;" class="bx-clone"><img src="images/blog16-420x295.jpg"
                                    height="295" width="420">
                                  </li>
                                </ul>
                              </div>
                              <div class="bx-controls bx-has-controls-direction">
                                <div class="bx-controls-direction"><a class="bx-prev" href="">Prev</a><a class="bx-next" href="">Next</a>
                                </div>
                              </div>
                            </div>
                            <div class="entry-thumb-desc">
                              <p>There are many variations of passages of Lorem Ipsum...</p>
                            </div>
                          </div>
                          <!-- .entry-thumb -->
                          <div class="entry-details">
                            <div class="entry-meta">
                              <div class="date">28 Jan </div>
                              <a href="http://wedesignthemes.com/themes/lms/blog/gallery-cumque-nihil-impedit/" class="entry_format"></a>
                            </div>
                            <div class="entry-title">
                              <h4><a href="http://wedesignthemes.com/themes/lms/blog/gallery-cumque-nihil-impedit/">Gallery - Cumque nihil impedit</a></h4>
                            </div>
                            <div class="entry-metadata">
                              <p class="author"><i class="fa fa-user"> </i> <a href="http://wedesignthemes.com/themes/lms/blog/author/ram/">ram</a>
                              </p><span> | </span>
                              <p class="tags"><i class="fa fa-tags"> </i><a href="http://wedesignthemes.com/themes/lms/blog/tag/blog-2/"> blog</a>,
                                <a href="http://wedesignthemes.com/themes/lms/blog/tag/chat/"> chat</a>
                              </p> <span> | </span>
                              <p class="comments"><a href="http://wedesignthemes.com/themes/lms/blog/gallery-cumque-nihil-impedit//#respond"
                                class="comments"><span class="fa fa-comments"> </span> 0</a>
                              </p>
                            </div>
                          </div>
                        </div>
                      </article>
                    </div>
                    <div class="column dt-sc-one-third">
                      <article class="blog-entry no-border post-482 post type-post status-publish format-status has-post-thumbnail hentry category-magazine category-photography category-photoshop tag-blog-2 tag-chat post_format-post-format-status">
                        <div class="blog-entry-inner">
                          <div class="entry-thumb">
                            <a href="http://wedesignthemes.com/themes/lms/blog/latin-words-ipsum/"><img src="images/blog17-420x295.jpg"
                              class="attachment-blogcourse-three-column-single-sidebar size-blogcourse-three-column-single-sidebar wp-post-image"
                              alt="blog17" srcset="http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-420x295.jpg 420w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-300x211.jpg 300w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-1024x719.jpg 1024w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-100x70.jpg 100w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17.jpg 1170w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-880x618.jpg 880w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-590x415.jpg 590w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-573x403.jpg 573w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-429x302.jpg 429w, http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/blog17-431x303.jpg 431w"
                              sizes="(max-width: 420px) 100vw, 420px" height="295" width="420">
                            </a>
                            <div class="entry-thumb-desc">
                              <p>There are many variations of passages of Lorem Ipsum...</p>
                            </div>
                          </div>
                          <!-- .entry-thumb -->
                          <div class="entry-details">
                            <div class="entry-meta">
                              <div class="date">28 Jan </div>
                              <a href="http://wedesignthemes.com/themes/lms/blog/latin-words-ipsum/" class="entry_format"></a>
                            </div>
                            <div class="entry-title">
                              <h4><a href="http://wedesignthemes.com/themes/lms/blog/latin-words-ipsum/">Latin words Ipsum</a></h4>
                            </div>
                            <div class="entry-metadata">
                              <p class="author"><i class="fa fa-user"> </i> <a href="http://wedesignthemes.com/themes/lms/blog/author/ram/">ram</a>
                              </p><span> | </span>
                              <p class="tags"><i class="fa fa-tags"> </i><a href="http://wedesignthemes.com/themes/lms/blog/tag/blog-2/"> blog</a>,
                                <a href="http://wedesignthemes.com/themes/lms/blog/tag/chat/"> chat</a>
                              </p> <span> | </span>
                              <p class="comments">
                                <a href="http://wedesignthemes.com/themes/lms/blog/latin-words-ipsum//#respond" class="comments"><span class="fa fa-comments"> </span> 2</a>
                              </p>
                            </div>
                          </div>
                        </div>
                      </article>
                    </div>
                  </div>
                </div>
                <div class="dt-sc-hr-invisible-medium  "></div>
                <div class="fullwidth-section custom-parallax dt-sc-parallax-section" style="background-image: url(&quot;http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/09/parallax-light-white.jpg&quot;); background-repeat: no-repeat; background-attachment: fixed;">
                  <div class="container">
                    <div class="dt-sc-hr-invisible-medium  "></div>
                    <div class="dt-sc-hr-invisible-medium  "></div>
                    <div class="column dt-sc-one-fourth  space  first">
                      <div class="dt-sc-ico-content type13">
                        <div class="custom-icon" style="background-color:#f2672e;"><a href="#" target="_blank">
                        <span class="fa fa-globe"></span></a>
                        </div>
                        <h4><a href="#" target="_blank">Know Your Business Planet</a></h4>
                      </div>
                    </div>
                    <div class="column dt-sc-one-fourth  space  ">
                      <div class="dt-sc-ico-content type13">
                        <div class="custom-icon" style="background-color:#0171bb;"><a href="#" target="_blank"><span class="fa  fa-keyboard-o"></span></a>
                        </div>
                        <h4><a href="#" target="_blank"> Play With Numbers </a></h4>
                      </div>
                    </div>
                    <div class="column dt-sc-one-fourth  space  ">
                      <div class="dt-sc-ico-content type13">
                        <div class="custom-icon" style="background-color:#9fbf3a;"><a href="#" target="_blank">
                        <span class="fa fa-file-text"></span></a>
                        </div>
                        <h4><a href="#" target="_blank"> Elevator Page </a></h4>
                      </div>
                    </div>
                    <div class="column dt-sc-one-fourth  space  ">
                      <div class="dt-sc-ico-content type13">
                         <div class="custom-icon" style="background-color:#9fbf3a;"><a href="#" target="_blank">
                        <span class="fa fa-eye"></span></a>
                        </div>
                        <h4><a href="#" target="_blank"> Insight </a></h4>
                      </div>
                    </div>
                   
                   
                    <div class="dt-sc-hr-invisible-medium  "></div>
                    <div class="dt-sc-hr-invisible  "></div>
                  </div>
                </div>
                <div class="dt-sc-hr-invisible-medium  "></div>
                <div class="fullwidth-section  ">
                  <div class="container">
                    <h2 class="border-title  ">Testimonials<span></span></h2>
                    <div class="dt-sc-events-carousel-wrapper">
                      <div class="caroufredsel_wrapper" style="display: block; text-align: start; float: none; position: relative; top: auto; right: auto; bottom: auto; left: auto; z-index: auto; width: 1180px; height: 141px; margin: 0px 0px 20px; overflow: hidden;">
                        <ul class="dt-sc-events-carousel" style="text-align: left; float: none; position: absolute; top: 0px; right: auto; bottom: auto; left: 0px; margin: 0px; width: 4720px; height: 141px;">
                          <li class="dt-sc-one-half column " id="post-3636" style="width: 572px;">
                            <div class="dt-sc-event-container">
                              <div class="dt-sc-event-thumb">
                                <a href="#" title="Welcoming 25th Batch"><img src="images/course11-420x295.jpg"
                                  class="attachment-blogcourse-three-column size-blogcourse-three-column wp-post-image"
                                  alt="course11" title="Welcoming 25th Batch"
                                  height="295" width="420">
                                </a><span class="event-price">$60</span>
                              </div>
                              <div class="dt-sc-event-content">
                                <h2><a href=#">Welcoming 25th Batch</a></h2>
                                <div class="dt-sc-event-meta">
                                  <p> <i class="fa fa-calendar-o"> </i>Jul 2017 @ 08 am - Mar 2025 @ 10 pm </p>
                                  <p>
                                    <i class="fa fa-map-marker"> </i><a href="http://wedesignthemes.com/themes/lms/venue/peppard-hill/">Peppard Hill</a>,
                                    United States<a href="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=AL+United+States"
                                    title="Peppard Hill" target="_blank"> + Google Map </a>
                                  </p>
                                </div>
                              </div>
                            </div>
                          </li>
                          <li class="dt-sc-one-half column " id="post-3639" style="width: 572px;">
                            <div class="dt-sc-event-container">
                              <div class="dt-sc-event-thumb">
                                <a href="http://wedesignthemes.com/themes/lms/event/fast-track-course-opening/" title="Fast Track Course Opening"><img src="images/course9-420x295.jpg"
                                  class="attachment-blogcourse-three-column size-blogcourse-three-column wp-post-image"
                                  alt="course9" title="Fast Track Course Opening"
                                  height="295" width="420">
                                </a><span class="event-price">$20</span>
                              </div>
                              <div class="dt-sc-event-content">
                                <h2><a href="http://wedesignthemes.com/themes/lms/event/fast-track-course-opening/">Fast Track Course Opening</a></h2>
                                <div class="dt-sc-event-meta">
                                  <p> <i class="fa fa-calendar-o"> </i>Aug 2017 @ 09 am - Aug 2024 @ 06 pm </p>
                                  <p>
                                    <i class="fa fa-map-marker"> </i>
                                    <a href="#">Rippon Building</a>,
                United Kingdom<a href="#"
                                    title="Rippon Building" target="_blank"> + Google Map </a>
                                  </p>
                                </div>
                              </div>
                            </div>
                          </li>
                          <li class="dt-sc-one-half column " id="post-3633" style="width: 572px;">
                            <div class="dt-sc-event-container">
                              <div class="dt-sc-event-thumb">
                                <a href="#" title="Free Yoga Class at London"><img src="images/course5-420x295.jpg"
                                  class="attachment-blogcourse-three-column size-blogcourse-three-column wp-post-image"
                                  alt="course5" title="Free Yoga Class at London"
                                  srcset="http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/05/course5-420x295.jpg 420w,
                                 
                                  sizes="(max-width: 420px) 100vw, 420px" height="295" width="420">
                                </a>
                              </div>
                              <div class="dt-sc-event-content">
                                <h2><a href="http://wedesignthemes.com/themes/lms/event/free-seminar-at-london/">Free Yoga Class at London</a></h2>
                                <div class="dt-sc-event-meta">
                                  <p> <i class="fa fa-calendar-o"> </i>Sep 2015 @ 10 am - Oct 2020 @ 06 pm </p>
                                  <p>
                                    <i class="fa fa-map-marker"> </i><a href="#">Pound Lane</a>,
                                    United States<a href="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Thov+Bridge+Las+Angels+United+States"
                                    title="Pound Lane" target="_blank"> + Google Map </a>
                                  </p>
                                </div>
                              </div>
                            </div>
                          </li>
                        </ul>
                      </div>
                      <div class="carousel-arrows">
                        <a class="events-prev" href="" style="display: block;"></a>
                        <a class="events-next" href="" style="display: block;"></a>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="dt-sc-hr-invisible-medium  "></div>
                <div class="fullwidth-section skin-color dt-sc-parallax-section" style="background-image:url(http://wedesignthemes.com/themes/lms/wp-content/uploads/2014/08/newsletter-parallax.png);background-repeat:no-repeat;background-position:left top;background-attachment:fixed; ">
                  <div class="container">
                    <div class="dt-sc-hr-invisible-medium  "></div>
                    <section id="newsletter">
                      <h2 class="border-title aligncenter">Get in touch with us</h2>
                      <h6> There are many variations of passages of Lorem Ipsum 
available, but the majority have suffered alteration in some form, by 
injected humour, or randomised words which Ipsum slightly believable </h6>
                      <form name="frmNewsletter" method="post" class="dt-sc-subscribe-frm">
                        <input name="dt_mc_emailid" id="dt_mc_emailid" required="" placeholder="Your Email Address" type="email">
                        <input name="dt_mc_apikey" id="dt_mc_apikey" value="c94a1d38b6683d601a324aeeb4d4ffe3-us1" type="hidden">
                        <input name="dt_mc_listid" id="dt_mc_listid" value="314bbca712" type="hidden">
                        <input name="submit" class="dt-sc-button small" value="Subscribe" type="submit">
                      </form>
                      <div id="ajax_newsletter_msg"></div>
                    </section>
                    <div class="dt-sc-hr-invisible-medium  "></div>
                  </div>
                </div>
                <div class="dt-sc-hr-invisible-medium  "></div>
                <div class="fullwidth-section  ">
                  <div class="container">
                    <h2 class="border-title aligncenter ">Our Process<span></span></h2>
                    <div class="dt-sc-hr-invisible  "></div>
                    <div class="dt-sc-timeline-section">
                      <div class="dt-sc-timeline left ">
                        <div class="dt-sc-one-half column first">
                          <div class="dt-sc-timeline-content">
                            <h2><a href="#"> Step 01 </a> </h2>
                            <h4>Search for your course</h4>
                            <p><i class="fa fa-timeline-icon1"> </i>Nemo enim ipsam voluptatem quia voluptas sit atur
                              aut odit aut fugit, sed quia consequuntur magni res.</p>
                          </div>
                        </div>
                      </div>
                      <div class="dt-sc-timeline right ">
                        <div class="dt-sc-one-half column first">
                          <div class="dt-sc-timeline-content">
                            <h2><a href="#"> Step 02 </a> </h2>
                            <h4>Take a Sample Lesson</h4>
                            <p><i class="fa fa-timeline-icon2"> </i>Nemo enim ipsam voluptatem quia voluptas sit atur
                              aut odit aut fugit, sed quia consequuntur magni res.</p>
                          </div>
                        </div>
                      </div>
                      <div class="dt-sc-timeline left ">
                        <div class="dt-sc-one-half column first">
                          <div class="dt-sc-timeline-content">
                            <h2><a href="#"> Step 03 </a> </h2>
                            <h4>Preview the Syllabus</h4>
                            <p><i class="fa fa-timeline-icon3"> </i>Nemo enim ipsam voluptatem quia voluptas sit atur
                              aut odit aut fugit, sed quia consequuntur magni res.</p>
                          </div>
                        </div>
                      </div>
                      <div class="dt-sc-timeline right ">
                        <div class="dt-sc-one-half column first">
                          <div class="dt-sc-timeline-content">
                            <h2><a href="#"> Step 04 </a> </h2>
                            <h4>Purchase the Course</h4>
                            <p><i class="fa fa-timeline-icon4"> </i>Nemo enim ipsam voluptatem quia voluptas sit atur
                              aut odit aut fugit, sed quia consequuntur magni res.</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="dt-sc-hr-invisible-medium  "></div>
                <div class="container">
                  <div class="social-bookmark"></div>
                  <div class="social-share"></div>
                </div>
              </div>
              <!-- #post-3633 -->

            </section>
            <!-- ** Primary Section End ** -->
          </div>